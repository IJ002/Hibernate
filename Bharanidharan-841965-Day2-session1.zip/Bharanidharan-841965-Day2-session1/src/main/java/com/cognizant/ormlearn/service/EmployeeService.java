package com.cognizant.ormlearn.service;

import java.util.HashSet;
import java.util.Set;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cognizant.ormlearn.model.Employee;
import com.cognizant.ormlearn.model.Skill;
import com.cognizant.ormlearn.repository.EmployeeRepository;

@Service
public class EmployeeService {
	@Autowired
	EmployeeRepository employeeRepository;
	private final static Logger LOGGER = LoggerFactory.getLogger(EmployeeService.class);
	private Employee employee;
	
	@Transactional
	public Employee get(int id) {
	LOGGER.info("Start");
	return employeeRepository.findById(id).get();
	}
	
	@Transactional
	public void save(Employee employee) {
	LOGGER.info("Start");
	employeeRepository.save(employee);
	LOGGER.info("End");

	}

	@Transactional
	public void addEmployee(Employee employee) {
		LOGGER.info("start");
		employeeRepository.save(employee);
		LOGGER.info("end");
	}
	@Transactional
	public void updateEmployee() {
		employee = this.get(1);
		employee.setName("sathish");
		employeeRepository.save(employee);
	}
	@Transactional
	public void addSkill() {
		employee = this.get(4);
		Skill skill = new Skill();
		skill.setId(1);
		Set<Skill> set = new HashSet<>();
		set.add(skill);
		employee.setSkillList(set);
		employeeRepository.save(employee);
		
	}
}
