package com.cognizant.ormlearn;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.cognizant.ormlearn.model.Department;
import com.cognizant.ormlearn.model.Employee;
import com.cognizant.ormlearn.service.DepartmentService;
import com.cognizant.ormlearn.service.EmployeeService;
import com.cognizant.ormlearn.service.SkillService;

@ComponentScan(basePackages="com.cognizant")
@SpringBootApplication
public class OrmLearnApplication {
	public static EmployeeService employeeService;
	public static DepartmentService departmentService;
	public static SkillService skillService;
	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);
	
	public static void main(String[] args) throws ParseException {
		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
		departmentService = context.getBean(DepartmentService.class);
		employeeService=context.getBean(EmployeeService.class);
		skillService=context.getBean(SkillService.class);
		LOGGER.info("Inside Main By Logger");
		//testGetEmployee();
		//testAddEmployee();
		//testUpdateEmployee();
		//testGetDepartment();
		//testAddSkillToEmployee();
	}
	private static void testGetEmployee() {
		LOGGER.info("Start");
		Employee employee = employeeService.get(1);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.debug("Department:{}", employee.getDepartment());
		LOGGER.debug("Skills:{}", employee.getSkillList());
		LOGGER.info("End");
		}
	private static void testAddEmployee() throws ParseException {
		Employee employee = new Employee();
		LOGGER.info("Start");
		Department department = new Department();
		department.setName("Insurance");
		departmentService.save(department);
		employee.setName("Kumar");
		employee.setPermanent(true);
		employee.setDateOfBirth(new SimpleDateFormat("yyyy-mm-dd").parse("1998-12-02"));
		employee.setSalary(12000.50);
		employee.setDepartment(departmentService.get(1));
		employeeService.addEmployee(employee);
		employeeService.save(employee);
		employee = employeeService.get(1);
		LOGGER.debug("EMPLOYEE:{}",employee);
		LOGGER.debug("Department:{}",employee.getDepartment());
		LOGGER.info("End");
	}
	private static void testUpdateEmployee() {
		employeeService.updateEmployee();
	}
	private static void testGetDepartment() {
		LOGGER.info("start");
		List<Department> departments = departmentService.getDepartment();
		LOGGER.info("{}", departments);
		LOGGER.info("{}",departments.get(0).getEmployeeList());
	}
	private static void testAddSkillToEmployee() {
		LOGGER.info("start");
		employeeService.addSkill();
		LOGGER.info("end");
	}
} 
