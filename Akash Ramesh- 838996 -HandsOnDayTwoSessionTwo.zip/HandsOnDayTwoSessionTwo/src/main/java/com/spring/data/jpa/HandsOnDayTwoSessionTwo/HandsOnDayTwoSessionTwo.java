package com.spring.data.jpa.HandsOnDayTwoSessionTwo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.spring.data.jpa.model.Question;
import com.spring.data.jpa.model.User;
import com.spring.data.jpa.service.QuestionService;
import com.spring.data.jpa.service.UserService;

@SpringBootApplication
@EntityScan(basePackages = "com.spring.data.jpa.model")
@ComponentScan(basePackages = "com.spring.data.jpa.service")
@EnableJpaRepositories(basePackages = "com.spring.data.jpa.repo")
public class HandsOnDayTwoSessionTwo implements CommandLineRunner {

	@Autowired
	UserService service;

	@Autowired
	QuestionService questionService;

	public static void main(String[] args) {
		SpringApplication.run(HandsOnDayTwoSessionTwo.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		testUserDetails();
		testQuestionDetails();

	}

	public void testUserDetails() {

		List<User> users = service.getAllUsers();

		for (User user : users) {
			System.out.println(user);
		}
	}

	public void testQuestionDetails() {
		List<Question> questions = questionService.getAllQuestions();

		questions.forEach(question -> {
			System.out.println(question);
		});

	}

}
