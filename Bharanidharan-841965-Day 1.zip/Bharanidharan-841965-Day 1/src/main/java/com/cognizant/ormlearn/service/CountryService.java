package com.cognizant.ormlearn.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.exceptions.CountryNotFoundException;
import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.repository.CountryRepository;

@Service
public class CountryService {

@Autowired
CountryRepository countryRepository;
@Transactional
public List<Country> getAllCountries(){
	List<Country> country = countryRepository.findAll();
	return country;	
}
@Transactional
public Country findCountryByCode(String countryCode)throws CountryNotFoundException{
	Optional<Country> result = countryRepository.findById(countryCode);
	if (!result.isPresent())
		throw new CountryNotFoundException("No Countries found!");
	Country country=result.get();
	return country;
}
@Transactional

public void addCountry(Country country) {
	countryRepository.save(country);
}
@Transactional
public void updateCountry(String code, String name) {
	Optional<Country> country= countryRepository.findById(code);
	Country c = country.get();
	c.setName(name);
	countryRepository.save(c);
}
@Transactional
public void deleteCountry(String id) throws CountryNotFoundException {
	Optional<Country> result = countryRepository.findById(id);
	if (!result.isPresent())
			throw new CountryNotFoundException("No Such country to Delete!");
		
	else
		countryRepository.deleteById(id);
}
}
