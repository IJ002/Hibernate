package com.cognizant.ormlearn.application;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.ormlearn.service.CountryService;
import com.cognizant.ormlearn.service.exception.CountryNotFoundException;

@SpringBootApplication
@ComponentScan("com")
@EnableJpaRepositories("com.ormlearm.repository")
@EntityScan("com.ormlearm.model")
public class OrmLearnApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);
	private static CountryService countryService;

	public static void main(String[] args) throws CountryNotFoundException {
		LOGGER.info("Inside main");
		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
		countryService = context.getBean(CountryService.class);
		updateTest("VK", "Vamsi_Test");
	}

//	private static void testGetAllCountries() {
//
//		LOGGER.info("Start");
//
//		List<Country> countries = countryService.getAllCountries();
//		System.out.println(countries);
//
//		LOGGER.debug("countries={}", countries);
//
//		LOGGER.info("End");
//
//	}

//	private static void addCountryTest() {
//
//		LOGGER.info("Start");
//		
//		Country country = new Country();
//		country.setCode("IM");
//		country.setName("Imaginary Country");
//
//		countryService.addCountry(country);
//
//		LOGGER.debug("Country:{}", country);
//
//		LOGGER.info("End");
//
//		}

	private static void updateTest(String code, String name) throws CountryNotFoundException {

		LOGGER.info("Start");

		countryService.updateCountryByCode(code, name);

		LOGGER.info("End");

	}

}
