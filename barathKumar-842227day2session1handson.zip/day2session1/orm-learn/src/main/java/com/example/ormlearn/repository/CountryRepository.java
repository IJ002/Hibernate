package com.example.ormlearn.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.ormlearn.model.Country;

@Repository
public interface CountryRepository extends JpaRepository<Country, String> {
	
	List<Country> findByNameContaining(String exp);
	
	List<Country> findByNameContainingOrderByName(String exp);
	
	List<Country> findByNameStartingWith(String exp);
	
}
