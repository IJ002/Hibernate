package com.example.ormlearn;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.example.ormlearn.model.Stock;
import com.example.ormlearn.service.StockService;



public class StockMain {

	@Autowired
	static private StockService stockService;
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(OrmLearnApplication.class, args);
		System.out.println("inside stock"+new Date(2019,9,3));
		
		

	}

}
