package com.cognizant.ormlearn.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Stock {
	@Id
	@Column(name="st_id")
	private Integer id;
	@Column(name="st_code")
	private String code;
	@Temporal(TemporalType.DATE)
	@Column(name="st_date")
	private Date date;
   @Column(name = "st_open",columnDefinition = "decimal",precision = 10,scale = 2)	
	private Float open;
   @Column(name = "st_close",columnDefinition = "decimal",precision = 10,scale = 2)
	private Float close;
   @Column(name="st_volume",columnDefinition = "decimal")
	private Long volume;
	@Override
public String toString() {
	return "Stock [id=" + id + ", code=" + code + ", date=" + date + ", open=" + open + ", close=" + close + ", volume="
			+ volume + "]";
}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Float getOpen() {
		return open;
	}
	public void setOpen(Float open) {
		this.open = open;
	}
	public Float getClose() {
		return close;
	}
	public void setClose(Float close) {
		this.close = close;
	}
	public Long getVolume() {
		return volume;
	}
	public void setVolume(Long volume) {
		this.volume = volume;
	}
	

}
