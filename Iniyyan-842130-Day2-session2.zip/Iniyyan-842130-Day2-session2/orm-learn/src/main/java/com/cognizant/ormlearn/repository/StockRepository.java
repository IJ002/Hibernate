package com.cognizant.ormlearn.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.ormlearn.model.Stock;
@Repository
public interface StockRepository extends JpaRepository<Stock, Integer> {
    @Query(value="select * from stock where MONTH(st_date)=?1 and st_code=?2",nativeQuery = true)
	List<Stock> findByDate(Integer month,String code);

   
    @Query(value = "select * from  stock where st_close>=?1 and st_code=?2",nativeQuery = true)
	List<Stock> findByStockPrice(Float f,String code);

    @Query(value="select *  from stock order by st_volume desc limit 3",nativeQuery = true)
	List<Stock> findByTopVolume();

   @Query(value = "select * from stock where st_code='NFLX' order by st_volume asc limit 3",nativeQuery = true)
	List<Stock> findByLowNet();


	

}
