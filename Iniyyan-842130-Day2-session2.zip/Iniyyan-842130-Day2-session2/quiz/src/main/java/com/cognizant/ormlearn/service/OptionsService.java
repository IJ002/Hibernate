package com.cognizant.ormlearn.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.Options;
import com.cognizant.ormlearn.repository.OptionsRepository;

@Service
public class OptionsService {
   @Autowired
   public OptionsRepository optionsRepository;
   
public List<Options> getOptions(Integer id) {
	// TODO Auto-generated method stub
	return optionsRepository.getByQuesId(id);
} 
}
