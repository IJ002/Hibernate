package com.cognizant.ormlearn.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class Attempt {
	@Id
	@Column( name = "at_id")
	private int id;
	@Column(name = "at_date")
	private Date date;
	@Column(name = "at_score",nullable = true)
	private double score;

	@Column(name = "at_us_id")
	private int userId;
	public int getId() {
		return id;
	}
	@Override
	public String toString() {
		return "Attempt [id=" + id + ", date=" + date + ", score=" + score + "]";
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}

	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	

}