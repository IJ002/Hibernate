package com.cognizant.ormlearn;

import java.util.List;

import org.aspectj.weaver.patterns.TypePatternQuestions.Question;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.cognizant.ormlearn.model.Attempt;
import com.cognizant.ormlearn.model.Options;
import com.cognizant.ormlearn.service.AttemptService;
import com.cognizant.ormlearn.service.OptionsService;
import com.cognizant.ormlearn.service.QuestionService;
import com.cognizant.ormlearn.service.UserService;

@SpringBootApplication
@ComponentScan(basePackages = "com.cognizant.ormlearn")
public class QuizApplication {
      public static AttemptService attemptService;
      public static UserService userService;
      public static OptionsService optionsService;
      public static QuestionService questionService;
      private static final Logger LOGGER = LoggerFactory.getLogger(QuizApplication.class);
	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(QuizApplication.class, args);
		attemptService = context.getBean(AttemptService.class);
		userService = context.getBean(UserService.class);
		optionsService = context.getBean(OptionsService.class);
		questionService = context.getBean(QuestionService.class);
		//testGetAttempt();
		testQuestion();
	}
	private static void testQuestion() {
		// TODO Auto-generated method stub
		List<com.cognizant.ormlearn.model.Question> qlist = questionService.getAll();
		for(com.cognizant.ormlearn.model.Question q : qlist) {
			 List<Options> options = optionsService.getOptions(q.getId());
			 LOGGER.debug(q.getText());
			 for(Options o: options) {
				 LOGGER.debug(o.getText());
				 double score = o.getScore();
				 LOGGER.debug(""+score+"");
				 if(score<1) {
					 LOGGER.debug("False");
				 }else {
					 LOGGER.debug("True");
				 }
			 }
		}
		
		
	}
	private static void testGetAttempt() {
		// TODO Auto-generated method stub
		LOGGER.info("Start");

		Attempt attempt= attemptService.getAttempt(1,1);

		LOGGER.debug("Attempts:{}", attempt);

	

		LOGGER.info("End");
		
	}

}
