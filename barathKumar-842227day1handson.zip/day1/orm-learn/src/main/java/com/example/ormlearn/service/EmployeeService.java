package com.example.ormlearn.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ormlearn.model.Employee;
import com.example.ormlearn.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository empRepo;
	
	@Transactional
	public void addEmployee(Employee employee) {

	empRepo.save(employee);

	}

}
