package com.example.ormlearn.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ormlearn.exception.CountryNotFoundException;
import com.example.ormlearn.model.Country;
import com.example.ormlearn.repository.CountryRepository;

@Service
public class CountryService {
	
	@Autowired
	CountryRepository countryRepo;
	

	public Iterable<Country> createStudentDetails(List<Country> elist) {
		return  countryRepo.saveAll(elist);
		
		// TODO Auto-generated method stub
		
	}


	public List<Country> getAllCountries() {
		// TODO Auto-generated method stub
		return countryRepo.findAll();
	}
	
	
	@Transactional
	public Country findCountryByCode(String countryCode) throws CountryNotFoundException{
		Optional<Country> result = countryRepo.findById(countryCode);
		if (!result.isPresent())
			throw new CountryNotFoundException("Choose other country!");
		return result.get();
		
	}
	
	@Transactional
	public void addCountry(Country country) {
		countryRepo.save(country);
	}
	
	@Transactional
	public void updateCountry(String code,String name) {
		
		Optional<Country> country = countryRepo.findById(code);
		Country country2 = country.get();
		country2.setName(name);
	}
	
	@Transactional
	public Country getCountry(String code) {
		return countryRepo.findById(code).get();
	}

	@Transactional
	public void deleteCountry(String code)
	{
		countryRepo.deleteById(code);
	}

}
