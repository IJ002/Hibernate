package com.example.ormlearn;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Service;

import com.example.ormlearn.exception.CountryNotFoundException;
import com.example.ormlearn.model.Country;
import com.example.ormlearn.model.Employee;
import com.example.ormlearn.service.CountryService;
import com.example.ormlearn.service.EmployeeService;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;


@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.example.ormlearn.repository")
@ComponentScan("com.example.ormlearn")
public class OrmLearnApplication implements CommandLineRunner {
	
	@Autowired
	CountryService service;
	@Autowired
	EmployeeService empService;
	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);


	public static void main(String[] args) {
		SpringApplication.run(OrmLearnApplication.class, args);
		LOGGER.info("Inside main");
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("spring app");
//		List<Country> elist=new ArrayList<Country>();
//		Country c1=new Country("IN", "India");
//		Country c2=new Country("CHN", "Chennai");
//		elist.add(c1);elist.add(c2);
//		service.createStudentDetails(elist);
		testGetAllCountries();
		
		
		Employee emp=new Employee("barath","123");
		empService.addEmployee(emp);
		
		
		getAllCountriesTest();
		
		service.addCountry(new Country("QW","Qwertys"));
		
		System.err.println("Added country:"+service.getCountry("QW"));
		
		service.updateCountry("QW", "BarathCOuntry");
		
		System.err.println("Updateds country:"+service.getCountry("QW"));
		
		service.deleteCountry("QW");
		try {
		System.err.println("Deleted country:"+service.getCountry("QW"));
		}catch (Exception e) {
			// TODO: handle exception
			System.err.println(e);
		}
		
	}

	private void testGetAllCountries() {
		List<Country> allCountries = service.getAllCountries();
		allCountries.forEach(e->System.err.println(e));
		LOGGER.info("Start");

		List<Country> countries = service.getAllCountries();

		LOGGER.debug("countries={}", countries);

		LOGGER.info("End");
	}
	private void getAllCountriesTest() {

		LOGGER.info("Start");

		Country country = null;
		try {
			country = service.findCountryByCode("IN");
		} catch (CountryNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		LOGGER.debug("Country:{}", country);
		System.err.println(country);

		LOGGER.info("End");

		}

}
