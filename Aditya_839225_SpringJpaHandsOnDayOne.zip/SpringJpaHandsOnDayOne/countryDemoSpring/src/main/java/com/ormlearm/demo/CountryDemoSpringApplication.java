package com.ormlearm.demo;

import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.ormlearm.model.Country;
import com.ormlearm.service.CountryService;
import com.ormlearm.service.exception.CountryNotFoundException;

@SpringBootApplication
@ComponentScan("com")
@EnableJpaRepositories("com.ormlearm.repository")
@EntityScan("com.ormlearm.model")
public class CountryDemoSpringApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(CountryDemoSpringApplication.class);
	private static CountryService countryService;

	public static void main(String[] args) throws CountryNotFoundException {
		// SpringApplication.run(CountryDemoSpringApplication.class, args);
		LOGGER.info("Inside main");
		ApplicationContext context = SpringApplication.run(CountryDemoSpringApplication.class, args);
		countryService = context.getBean(CountryService.class);
		updateTest("IM", "Himanshu_Data");
	}

//	private static void testGetAllCountries() {
//
//		LOGGER.info("Start");
//
//		List<Country> countries = countryService.getAllCountries();
//		System.out.println(countries);
//
//		LOGGER.debug("countries={}", countries);
//
//		LOGGER.info("End");
//
//	}
	
//	private static void addCountryTest() {
//
//		LOGGER.info("Start");
//		
//		Country country = new Country();
//		country.setCode("IM");
//		country.setName("Imaginary Country");
//
//		countryService.addCountry(country);;
//
//		LOGGER.debug("Country:{}", country);
//
//		LOGGER.info("End");
//
//		}
	
	private static void updateTest(String code, String name) throws CountryNotFoundException {

		LOGGER.info("Start");

		countryService.updateCountryByCode(code, name);;

		LOGGER.info("End");

		}

}
