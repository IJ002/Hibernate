package com.cognizant.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.model.Employee;
import com.cognizant.service.EmployeeService;

@SpringBootApplication
@ComponentScan("com")
@EnableJpaRepositories("com.cognizant.repository")
@EntityScan("com.cognizant.model")
public class EmployeeJpaDemoApplication implements CommandLineRunner {

	private static SessionFactory sessionFactory;
	
	@Autowired
	private EmployeeService employeeService;

	public static void main(String[] args) {
		SpringApplication.run(EmployeeJpaDemoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Employee employee = new Employee("Ramesh", "Fadatare", "Delhi");
		Employee employee1 = new Employee("John", "Cena", "USA");
		Transaction transaction = null;
		sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		employeeService.addEmployee(employee1);
		employeeService.addEmployee(employee);
		transaction.commit();

	}

}
