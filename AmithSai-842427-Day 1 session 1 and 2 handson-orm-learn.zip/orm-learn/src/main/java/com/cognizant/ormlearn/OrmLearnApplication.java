package com.cognizant.ormlearn;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.exceptions.CountryNotFoundException;
import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.service.CountryService;

@SpringBootApplication
public class OrmLearnApplication {

	private static CountryService countryService;
	private final static Logger logger = LoggerFactory.getLogger(OrmLearnApplication.class);

	public static void main(String[] args)  {
		logger.info("Inside Main");
		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
		countryService = context.getBean(CountryService.class);
		OrmLearnApplication.testGetAllCountries();
	
		try {
			OrmLearnApplication.getAllCountriesTest();
		} catch (CountryNotFoundException e2) {
			System.out.println(e2.getMessage());
		}
		try {
			OrmLearnApplication.testAddCountry();
		} catch (CountryNotFoundException e1) {
			System.out.println(e1.getMessage());
		}
		try {
			OrmLearnApplication.testUpdateCountry();
		} catch (CountryNotFoundException e1) {
			System.out.println(e1.getMessage());
		}
		try {
			OrmLearnApplication.testDeleteCountry();
		} catch (CountryNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	private static void testGetAllCountries() {
		logger.info("Start");
		List<Country> countries = countryService.getAllCountries();
		logger.debug("countries={}", countries);
		logger.info("End");
	}

	private static void getAllCountriesTest() throws CountryNotFoundException {
		logger.info("Start");
		Country country = countryService.findCountryByCode("IN");
		logger.debug("Country:{}", country);
		logger.info("End");
	}
	
	private static void testAddCountry() throws CountryNotFoundException {
		logger.info("Start");
		Country country = new Country();
		country.setCode("AM");
		country.setName("Amith");
		countryService.addCountry(country);
		logger.info("added country successfully");
		Country findCountryByCode = countryService.findCountryByCode("AM");
		logger.debug("Country:{}", findCountryByCode);
		logger.info("End");
	}
	
	private static void testUpdateCountry() throws CountryNotFoundException {
		logger.info("Start");
		countryService.updateCountry("AM");
		logger.info("updated country successfully");
		Country findCountryByCode = countryService.findCountryByCode("AM");
		logger.debug("Country:{}", findCountryByCode);
		logger.info("End");
	}
	
	private static void testDeleteCountry() throws CountryNotFoundException {
		logger.info("Start");
		countryService.deleteCountry("AM");
		logger.info("Deleted country successfully");
		Country findCountryByCode = countryService.findCountryByCode("AM");
		logger.debug("Country:{}", findCountryByCode);
		logger.info("End");
	}

}
