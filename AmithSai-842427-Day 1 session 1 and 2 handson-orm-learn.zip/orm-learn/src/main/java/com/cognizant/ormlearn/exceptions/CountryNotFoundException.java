package com.cognizant.ormlearn.exceptions;

@SuppressWarnings("serial")
public class CountryNotFoundException extends Exception{

	public CountryNotFoundException(String message) {
		super(message);
	}
}
