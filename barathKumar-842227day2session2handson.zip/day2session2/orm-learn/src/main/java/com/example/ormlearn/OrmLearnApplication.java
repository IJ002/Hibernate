package com.example.ormlearn;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Service;

import com.example.ormlearn.exception.CountryNotFoundException;
import com.example.ormlearn.model.Country;
import com.example.ormlearn.model.Department;
import com.example.ormlearn.model.Employee;
import com.example.ormlearn.model.Question;
import com.example.ormlearn.model.Skill;
import com.example.ormlearn.model.Stock;
import com.example.ormlearn.service.AttemptService;
import com.example.ormlearn.service.CountryService;
import com.example.ormlearn.service.DepartmentService;
import com.example.ormlearn.service.EmployeeService;
import com.example.ormlearn.service.OptionsService;
import com.example.ormlearn.service.QuestionService;
import com.example.ormlearn.service.SkillService;
import com.example.ormlearn.service.StockService;
import com.example.ormlearn.service.UserService;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.example.ormlearn.repository")
@ComponentScan("com.example.ormlearn")
public class OrmLearnApplication implements CommandLineRunner {

	@Autowired
	CountryService service;
	@Autowired
	EmployeeService empService;
	@Autowired
	StockService stockService;
	@Autowired
	DepartmentService departmentService;
	@Autowired
	SkillService skillService;
	
	@Autowired
	AttemptService attemptService;
	@Autowired
	QuestionService questionService;
	@Autowired
	OptionsService optionService;
	@Autowired
	UserService userService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(OrmLearnApplication.class, args);
		LOGGER.info("Inside main");
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("spring app");
//		List<Country> elist=new ArrayList<Country>();
//		Country c1=new Country("IN", "India");
//		Country c2=new Country("CHN", "Chennai");
//		elist.add(c1);elist.add(c2);
//		service.createStudentDetails(elist);
		testGetAllCountries();

/*
		getAllCountriesTest();

		service.addCountry(new Country("QW", "Qwertys"));

		System.err.println("Added country:" + service.getCountry("QW"));

		service.updateCountry("QW", "BarathCOuntry");

		System.err.println("Updateds country:" + service.getCountry("QW"));

		service.deleteCountry("QW");
		try {
			System.err.println("Deleted country:" + service.getCountry("QW"));
		} catch (Exception e) {
			// TODO: handle exception
			System.err.println(e);
		}

		//////////////////////////////////////////////////////////
		
		List<Country> countryMatchingString = service.findCountryMatchingString("co");

		countryMatchingString.forEach(e -> System.err.println(e));

		List<Country> countryMatchingStringOrderByName = service.findCountryMatchingStringOrderByName("co");

		System.out.println("ascending order");

		countryMatchingStringOrderByName.forEach(e -> System.err.println(e));

		System.out.println("Starting with Z");

		List<Country> countryStartsWith = service.countryStartsWith("Z");

		countryStartsWith.forEach(e -> System.err.println(e));
		
		System.out.println("Get all stock details of Facebook in the month of September 2019.");
		List<Stock> dateStock = stockService.getCodeAndDateStock("FB", new SimpleDateFormat("yyyy-MM-dd").parse("2019-01-01"));

		List<Stock> dateStockBet = stockService.getCodeAndDateStockBet("FB", new SimpleDateFormat("yyyy-MM-dd").parse("2019-01-01"),
				new SimpleDateFormat("yyyy-MM-dd").parse("2019-02-01"));
		System.out.println(dateStock);
		dateStockBet.forEach(e -> System.err.println(e));
		
		System.out.println("Stock price of google price greater than 1250");
		
		List<Stock> codeAndStockPrice = stockService.getCodeAndStockPrice("GOOGL", 1250.00F);
		
		codeAndStockPrice.forEach(e->System.err.println(e));
		
		System.out.println("Find the top 3 dates which had highest volume of transactions");
		
		List<Stock> topThreeRecordsOfVoume = stockService.getTopThreeRecordsOfVoume();
		
		topThreeRecordsOfVoume.forEach(e->System.err.println(e));
		
		System.out.println("Identify three dates when Netflix stocks were the lowest");
		
		List<Stock> topThreeRecordsOfStock = stockService.getTopThreeRecordsOfStock("NFLX");
		
		topThreeRecordsOfStock.forEach(e->System.err.println(e));
		
		
		
		testGetemployee();
	
		testAddEmployee();
		
		Employee employee = testUpdateEmployee();
		empService.save(employee);
		
		
		testGetDepartment();
		
		fetchingEmployeeAlongWithSkills(employee);
		
		AddSkilltoEmployee();
		*/
		
		testGetAllPermanentEmployees();
		
		quizHandson();
		
		System.err.println(empService.getAvgSalary(1));
		
		System.err.println(empService.getEmployeeNative());
		
		

		
		
	}

	private void quizHandson() {
		System.out.println(attemptService.getAttempt(1, 1));
		
		List<Question> questions = questionService.getQuestions();
		
		for(Question que:questions) {
			System.out.println(que.getQuestionText());
			List<String> options = optionService.getOptionForQuestion(que.getId());
			List<Integer> ans=optionService.getAns(que.getId());
			for(int i=0;i<options.size();i++)
			{
				System.err.print(options.get(i)+"  \t");
				System.err.print(ans.get(i)+" \t");
				if(ans.get(i)!=0) {
					System.err.println(true);
				}
				else
					System.err.println(false);
				System.out.println();
			}
		}
	}
	public void testGetAllPermanentEmployees() {

		LOGGER.info("Start");

		List<Employee> employees = empService.getAllPermanentEmployees();

		LOGGER.debug("Permanent Employees:{}", employees);

		//employees.forEach(e -> LOGGER.debug("Skills:{}", e.getSkillList()));
		employees.forEach(e->System.err.println(e));
		System.out.println(employees);

		LOGGER.info("End");

		}

	private void testAddEmployee() throws ParseException {
		LOGGER.debug("insert into employee values(?,?,?,?,?)");
		Employee emp=new Employee("barath", 1000, true, new SimpleDateFormat("yyyy-mm-dd").parse("1999-06-02"), departmentService.get(2));
		empService.addEmployee(emp);
		LOGGER.info(emp.toString());
	}

	private Employee testUpdateEmployee() {
		LOGGER.debug("update employee set department=? where id=?");
		Employee employee = empService.get(4);
		employee.setDepartment(departmentService.get(2));
		empService.save(employee);
		LOGGER.info("Updated employee"+employee);
		return employee;
	}

	private void testGetDepartment() {
		Department department = departmentService.get(2);
		System.err.println(department.getEmployeeList());
	}

	private void fetchingEmployeeAlongWithSkills(Employee employee) {
		Employee employee2 = empService.get(2);
		System.err.println(employee2.getSkillList());
		LOGGER.debug("Skills:{}", employee.getSkillList());
	}

	private void AddSkilltoEmployee() {
		Employee employee3 = empService.get(2);
		Skill skill = skillService.get(2);
		employee3.getSkillList().add(skill);
		empService.save(employee3);
		System.out.println(employee3.getSkillList());
	}

	private void testGetemployee() {
		LOGGER.info("Start");

		Employee employee = empService.get(1);

		LOGGER.debug("Employee:{}", employee);

		LOGGER.debug("Department:{}", employee.getDepartment());

		LOGGER.info("End");
	}
	
	
	
	
	
	
	
	

	private void testGetAllCountries() {
		List<Country> allCountries = service.getAllCountries();
		allCountries.forEach(e -> System.err.println(e));
		LOGGER.info("Start");

		List<Country> countries = service.getAllCountries();

		LOGGER.debug("countries={}", countries);

		LOGGER.info("End");
	}

	private void getAllCountriesTest() {

		LOGGER.info("Start");

		Country country = null;
		try {
			country = service.findCountryByCode("IN");
		} catch (CountryNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		LOGGER.debug("Country:{}", country);
		System.err.println(country);

		LOGGER.info("End");

	}

}
