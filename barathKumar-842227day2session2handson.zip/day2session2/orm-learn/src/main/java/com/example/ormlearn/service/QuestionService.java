package com.example.ormlearn.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ormlearn.model.Question;
import com.example.ormlearn.model.Skill;
import com.example.ormlearn.repository.QuestionRepository;

@Service
public class QuestionService {
	
	@Autowired
	QuestionRepository questionRepo;
	
	@Transactional
	public void addQuestion(Question skill) {

	questionRepo.save(skill);

	}
	@Transactional

	public Question get(int id) {

	return questionRepo.findById(id).get();

	}
	@Transactional

	public void save(Question skill) {

	questionRepo.save(skill);

	}
	public List<Question> getQuestions() {
		return questionRepo.findAll();
		// TODO Auto-generated method stub
		
	}

}
