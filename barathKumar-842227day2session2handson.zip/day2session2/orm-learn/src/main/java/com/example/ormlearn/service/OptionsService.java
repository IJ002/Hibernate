package com.example.ormlearn.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.ormlearn.model.Options;
import com.example.ormlearn.repository.OptionsRepository;

import net.bytebuddy.asm.Advice.Return;

@Service
public class OptionsService {
	
	@Autowired
	OptionsRepository optionRepo;
	
	@Transactional
	public void addEmployee(Options o) {

	optionRepo.save(o);

	}
	@Transactional

	public Options get(int id) {

	return optionRepo.findById(id).get();

	}
	@Transactional

	public void save(Options options) {

	optionRepo.save(options);

	}
	public List<String> getOptionForQuestion(Integer id) {
		// TODO Auto-generated method stub
		return optionRepo.getOptionForQuestion(id);
	}
	public List<Integer> getAns(Integer id) {
		// TODO Auto-generated method stub
		return optionRepo.getAns(id);
	}

}
