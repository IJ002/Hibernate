package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.example.model.Question;
import com.example.model.User;
import com.example.service.QuestionService;
import com.example.service.UserService;


@SpringBootApplication
@EntityScan(basePackages = "com.example.model")
@ComponentScan(basePackages = "com.example.service")
@EnableJpaRepositories(basePackages = "com.example.repo")
public class DayTwoSessionTwoApplication implements CommandLineRunner{

	@Autowired
	UserService userService;
	@Autowired
	QuestionService questionService;
	
	public static void main(String[] args) {
		SpringApplication.run(DayTwoSessionTwoApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		testUser();
		testQuestion();
	}

	private void testQuestion() {
		List <User> users = userService.getUser();
		for (User user : users) {
			System.out.println(user);
		}
	}

	private void testUser() {
		List <Question> questions = questionService.getQuestion();
		questions.forEach(question -> {
			System.out.println(question);
		});
	}

}
