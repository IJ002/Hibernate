package com.example.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Option {
	@Column(name = "op_id")
	@Id
	private Integer id;
	@Column(name = "op_qt_id")
	private Integer questionId;
	@Column(name = "op_score")
	private Double score;
	@Column(name = "op_text")
	private String text;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getquestionId() {
		return questionId;
	}
	public void setqId(Integer questionId) {
		this.questionId = questionId;
	}
	public Double getScore() {
		return score;
	}
	public void setScore(Double score) {
		this.score = score;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	
	
}
