package com.example.service;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DayTwoSessionTwoApplication;
import com.example.model.Question;
import com.example.repo.QuestionRepo;

@Service
public class QuestionService{
	private static final Logger LOGGER = LoggerFactory.getLogger(DayTwoSessionTwoApplication.class);

	@Autowired
	QuestionRepo repo;

	@Transactional
	public List<Question> getQuestion() {

		return repo.getQuestion();
	}
	
}
