package com.example.service;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DayTwoSessionTwoApplication;
import com.example.model.User;
import com.example.repo.UserRepo;

@Service
public class UserService {
	private static final Logger LOGGER = LoggerFactory.getLogger(DayTwoSessionTwoApplication.class);
	
	@Autowired
	UserRepo userRepo;
	
	@Transactional
	public List<User> getUser(){
		return userRepo.getUser();
	}
}
