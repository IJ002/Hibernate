package com.cognizant.ormlearn.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.repository.CountryRepository;

@Service
public class CountryService {

	@Autowired
	CountryRepository countryRepository;

	public List<Country> findAll() {
		return countryRepository.findAll();
	}

	public Country findById(String id) {

		return countryRepository.findByCode(id);

	}

	public void save(Country country) {

		countryRepository.save(country);
	}

	public void deleteByCode(String id) {
		countryRepository.deleteById(id);
	}

}
