package com.cognizant.ormlearn.ormlearnapplication;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.service.CountryService;

@SpringBootApplication
@EntityScan(basePackages = "com.cognizant.ormlearn.model")
@ComponentScan(basePackages = "com.cognizant.ormlearn.service")
@EnableJpaRepositories(basePackages = "com.cognizant.ormlearn.repository")
public class OrmLearnApplication implements CommandLineRunner {

	@Autowired
	CountryService countryService;

	public static void main(String[] args) {
		SpringApplication.run(OrmLearnApplication.class, args);
	}

	@Override

	public void run(String... args) throws Exception {

		
		
		Scanner sc = new Scanner(System.in);
		String id;
		System.out.println("Enter the country code: ");
		id = sc.next();

		Country countryByCode = countryService.findById(id);

		if (countryByCode == null) {
			System.out.println("There is no such country with the countrycode");
		} else {
			System.out.println("Country code: " + countryByCode.getCode());
			System.out.println("Country name: " + countryByCode.getName());
		}
		Country country = new Country();
		try {
			System.out.println("Country code: ");
			country.setCode(sc.next());
			System.out.println("Country name: ");
			country.setName(sc.next());
		} catch (Exception e) {
			System.out.println("Duplicate Entry");
			return;
		}
		countryService.save(country);
		System.out.println("Saved");

		System.out.println("Country to be updated: ");
		id = sc.next();

		if (countryService.findById(id) != null) {
			System.out.println("New Country's name: ");
			String countryName = sc.next();

			Country update = new Country();
			update.setCode(id);
			update.setName(countryName);

			countryService.save(update);
			System.out.println("Country name updated!");

		}
		
		System.out.println("Country to be deleted:");
		id = sc.next();
		
		countryService.deleteByCode(id);
		
	
	}

}
