package com.example.ormlearn.exception;

public class CountryNotFoundException extends Exception {
	
	public CountryNotFoundException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
