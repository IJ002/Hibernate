package com.example.ormlearn.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Employee {

	public Employee() {
		// TODO Auto-generated constructor stub
	}
	@Id
	@GeneratedValue
	@Column
	private Integer employee_id;
	@Column
	private String emloyee_name;
	@Column
	private String employee_phnno;
	
	
	public Employee( String emloyee_name, String employee_phnno) {
		super();
		
		this.emloyee_name = emloyee_name;
		this.employee_phnno = employee_phnno;
	}

	public Integer getEmployee_id() {
		return employee_id;
	}
	
	public String getEmloyee_name() {
		return emloyee_name;
	}
	public void setEmloyee_name(String emloyee_name) {
		this.emloyee_name = emloyee_name;
	}
	public String getEmployee_phnno() {
		return employee_phnno;
	}
	public void setEmployee_phnno(String employee_phnno) {
		this.employee_phnno = employee_phnno;
	}

	@Override
	public String toString() {
		return "Employee [employee_id=" + employee_id + ", emloyee_name=" + emloyee_name + ", employee_phnno="
				+ employee_phnno + "]";
	}

}
