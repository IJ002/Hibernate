package com.ormlearn.Day2Session1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.ormlearn.Day2Session1.model.Department;
import com.ormlearn.Day2Session1.model.Employee;
import com.ormlearn.Day2Session1.service.DepartmentService;
import com.ormlearn.Day2Session1.service.EmployeeService;

@SpringBootApplication
public class Day2Session1Application {

	private static EmployeeService employeeService;
	private static DepartmentService departmentService;
	private final static Logger logger = LoggerFactory.getLogger(Day2Session1Application.class);

	public static void main(String[] args) throws ParseException {
		ApplicationContext context = SpringApplication.run(Day2Session1Application.class, args);
		employeeService = context.getBean(EmployeeService.class);
//		Day2Session1Application.testAddEmployee(););
//		Day2Session1Application.testAddSkillToEmployee();
//		Day2Session1Application.testGetEmployee();
//		Day2Session1Application.testUpdateEmployee();
//		Day2Session1Application.testGet();
		departmentService = context.getBean(DepartmentService.class);
//		Day2Session1Application.testGetDepartments();


	}

	@SuppressWarnings("unused")
	private static void testAddEmployee() throws ParseException {
		Employee employee = new Employee();
		Department department = new Department();
		department.setId(1);
		employee.setName("Vinod");
		employee.setPermanent(true);
		employee.setDateOfBirth(new SimpleDateFormat("yyyy-mm-dd").parse("1999-06-02"));
		employee.setSalary(120000.02);
		employee.setDepartment(department);
		employeeService.addEmployee(employee);
	}

	@SuppressWarnings("unused")
	private static void testGet() {
		System.out.println(employeeService.get(1));
	}

	@SuppressWarnings("unused")
	private static void testGetEmployee() {
		logger.info("Start");
		Employee employee = employeeService.get(4);
		logger.debug("Employee:{}", employee);
		logger.debug("Department:{}", employee.getDepartment());
		logger.debug("{}",employee.getSkillList());
		System.out.println(employee.getSkillList());
		logger.info("End");

	}
	
	@SuppressWarnings("unused")
	private static void testUpdateEmployee() {
		employeeService.updateEmployee();
	}
	
	@SuppressWarnings("unused")
	private static void testGetDepartments() {
		logger.info("start");
		List<Department> departments = departmentService.getDepartments();
		logger.info("{}", departments);
		logger.info("{}",departments.get(0).getEmployee());
	}
	
	@SuppressWarnings("unused")
	private static void testAddSkillToEmployee() {
		logger.info("start");
		employeeService.addSkill();
		logger.info("end");
	}

}
