package com.ormlearn.Day2Session1.service;

import org.springframework.stereotype.Service;

@Service
public class SkillService {


}
