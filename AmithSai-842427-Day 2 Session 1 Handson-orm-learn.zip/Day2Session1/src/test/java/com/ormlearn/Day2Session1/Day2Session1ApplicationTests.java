package com.ormlearn.Day2Session1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day2Session1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
