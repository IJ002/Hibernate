package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="options")
@Entity(name="options")
public class Options {

	public Options() {	}
	@Id
	@GeneratedValue
	@Column(name = "optionId")
	private Integer id;
	@Column(name = "quesId")
	private Integer questionId;
	@Column(name = "optionScore")
	private Double optionScore;
	@Column(name = "optionText")
	private String optionText;
	public Integer getQuestionId() {
		return questionId;
	}
	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}
	public Double getOptionScore() {
		return optionScore;
	}
	public void setOptionScore(Double optionScore) {
		this.optionScore = optionScore;
	}
	public String getOptionTexts() {
		return optionText;
	}
	public void setOptionTexts(String optionText) {
		this.optionText = optionText;
	}

}
