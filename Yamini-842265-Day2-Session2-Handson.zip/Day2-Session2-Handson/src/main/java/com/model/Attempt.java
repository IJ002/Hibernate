package com.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="attempt")
@Table(name="attempt")
public class Attempt {

	@Id
	@GeneratedValue
	@Column(name = "attemptId")
	private Integer id;
	@Column(name = "attemptDate")
	private Date date;
	@Column(name = "userId")
	private Integer userId;
	@Column(name = "Score")
	private Double score;
	
	@Override
	public String toString() {
		return "Attempt [id=" + id + ", date=" + date + ", userId=" + userId + ", score=" + score + "]";
	}
}
