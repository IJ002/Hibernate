package com.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="question")
@Entity(name="question")
public class Question {
	public Question() {
		// TODO Auto-generated constructor stub
	}
	@Id
	@GeneratedValue
	@Column(name = "quesId")
	private Integer qid;
	@Column(name = "quesText")
	private String text;
	

	public String getQuestionText() {
		return text;
	}
	public void setQuestionText(String questionText) {
		this.text = questionText;
	}
	public Integer getId() {
		// TODO Auto-generated method stub
		return qid;
	}

}
