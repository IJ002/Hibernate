package com.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity(name="stock")
@Table(name="stock")
public class Stock {

	@Id
	@GeneratedValue
	@Column(name = "stockId")
	private Integer id;
	@Column(name = "stockCode")
	private String code;
	@Column(name = "stockDate")
	@Temporal(TemporalType.DATE)
	private Date date;
	@Column(name = "stockOpen",columnDefinition = "decimal",precision = 10,scale = 2)
	private Float open;
	public Stock() {
		super();
	}
	@Column(name = "stockClose",columnDefinition = "decimal",precision = 10,scale = 2)
	private Float close;
	@Column(name = "volume",columnDefinition = "decimal")
	private Long volume;
	@Override
	public String toString() {
		return "Stock [id=" + id + ", code=" + code + ", date=" + date + ", open=" + open + ", close=" + close
				+ ", volume=" + volume + "]";
	}

}
