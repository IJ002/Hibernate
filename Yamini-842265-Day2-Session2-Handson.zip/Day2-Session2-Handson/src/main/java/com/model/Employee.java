package com.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name="employee")
@Table(name="employee")
public class Employee {
      public Employee( String name, double salary, boolean permanent, Date dateOfBirth,Department d) {
		super();
		this.name = name;
		this.salary = salary;
		this.permanent = permanent;
		this.dateOfBirth = dateOfBirth;
		this.department=d;
	}


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "empId")
	private int id;
	@Column(name="empName")
	private String name;
	@Column(name = "empSalary")
	private double salary;

	@ManyToOne
	@JoinColumn(name = "empDeptId")
	private Department department;
	
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "employeeSkill",
	joinColumns = @JoinColumn(name = "empId"),
	inverseJoinColumns = @JoinColumn(name = "skillId"))
	private Set<Skill> skillList;


	public Employee() {
		super();
	}



	@Column(name = "empPermanent")
	private boolean permanent;
	@Column(name = "DateOfBirth")
	private Date dateOfBirth;

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", department=" + department
				+ ", skillList=" + skillList + ", permanent=" + permanent + ", dateOfBirth=" + dateOfBirth + "]";
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public double getSalary() {
		return salary;
	}


	public void setSalary(double salary) {
		this.salary = salary;
	}


	public boolean isPermanent() {
		return permanent;
	}


	public void setPermanent(boolean permanent) {
		this.permanent = permanent;
	}


	public Date getDateOfBirth() {
		return dateOfBirth;
	}


	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	public Department getDepartment() {
		return department;
	}


	public void setDepartment(Department department) {
		this.department = department;
	}


	public Set<Skill> getSkillList() {
		return skillList;
	}


	public void setSkillList(Set<Skill> skillList) {
		this.skillList = skillList;
	}
	
	

}
