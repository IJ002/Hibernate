package com.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.model.Options;

@Repository
public interface OptionsRepository extends JpaRepository<Options, Integer> {

	@Query(value = "select op_text from options where op_qt_id=?1",nativeQuery = true)
	List<String> getOptionForQuestion(Integer id);

	@Query(value = "select op_score from options where op_qt_id=?1",nativeQuery = true)
	List<Integer> getAns(Integer id);

}
