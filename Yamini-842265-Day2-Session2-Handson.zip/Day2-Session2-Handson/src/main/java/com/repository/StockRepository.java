package com.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.model.Stock;

@Repository
public interface StockRepository extends JpaRepository<Stock, Integer> {
	
	List<Stock> findByCodeAndDateAfter(String code,Date date);
	
	List<Stock> findByCodeAndDateBetween(String code,Date date1,Date date2);
	
	List<Stock> findByCodeAndCloseAfter(String code,Float close);
	
	List<Stock> findTop3ByOrderByVolumeDesc();
	
	List<Stock> findTop3ByCodeOrderByCloseAsc(String code);
	
	

}
