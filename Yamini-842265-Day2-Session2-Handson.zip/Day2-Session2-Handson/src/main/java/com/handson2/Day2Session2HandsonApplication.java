package com.handson2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


import com.model.Country;

import com.model.Employee;
import com.model.Question;
import com.service.AttemptService;
import com.service.CountryService;
import com.service.DepartmentService;
import com.service.EmployeeService;
import com.service.OptionsService;
import com.service.QuestionService;
import com.service.SkillService;
import com.service.StockService;
import com.service.UserService;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.example.ormlearn.repository")
@ComponentScan("com.example.ormlearn")

public class Day2Session2HandsonApplication implements CommandLineRunner {
	
	@Autowired
	CountryService service;
	@Autowired
	EmployeeService empService;
	@Autowired
	StockService stockService;
	@Autowired
	DepartmentService departmentService;
	@Autowired
	SkillService skillService;
	
	@Autowired
	AttemptService attemptService;
	@Autowired
	QuestionService questionService;
	@Autowired
	OptionsService optionService;
	@Autowired
	UserService userService;

	private static final Logger LOGGER = LoggerFactory.getLogger(Day2Session2HandsonApplication.class);
	public static void main(String[] args) {
		SpringApplication.run(Day2Session2HandsonApplication.class, args);
		LOGGER.info("Inside main");
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		testGetAllCountries();
		
		testGetAllPermanentEmployees();
		
		quizHandson();
		
		System.err.println(empService.getAvgSalary(1));
		
		System.err.println(empService.getEmployeeNative());
				
	}

	private void quizHandson() {
		System.out.println(attemptService.getAttempt(1, 1));
		
		List<Question> questions = questionService.getQuestions();
		
		for(Question que:questions) {
			System.out.println(que.getQuestionText());
			List<String> options = optionService.getOptionForQuestion(que.getId());
			List<Integer> ans=optionService.getAns(que.getId());
			for(int i=0;i<options.size();i++)
			{
				System.err.print(options.get(i)+"  \t");
				System.err.print(ans.get(i)+" \t");
				if(ans.get(i)!=0) {
					System.err.println(true);
				}
				else
					System.err.println(false);
				System.out.println();
			}
		}
	}
	public void testGetAllPermanentEmployees() {

		LOGGER.info("Start");

		List<Employee> employees = empService.getAllPermanentEmployees();

		LOGGER.debug("Permanent Employees:{}", employees);

		//employees.forEach(e -> LOGGER.debug("Skills:{}", e.getSkillList()));
		employees.forEach(e->System.err.println(e));
		System.out.println(employees);

		LOGGER.info("End");

		}


	private void testGetAllCountries() {
		List<Country> allCountries = service.getAllCountries();
		allCountries.forEach(e -> System.err.println(e));
		LOGGER.info("Start");

		List<Country> countries = service.getAllCountries();

		LOGGER.debug("countries={}", countries);
		LOGGER.info("End");
	}

	

}
