package com.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Options;
import com.repository.OptionsRepository;


@Service
public class OptionsService {
	
	@Autowired
	OptionsRepository optionRepo;
	
	@Transactional
	public void addEmployee(Options o) {

	optionRepo.save(o);

	}
	@Transactional

	public Options get(int id) {

	return optionRepo.findById(id).get();

	}
	@Transactional

	public void save(Options options) {

	optionRepo.save(options);

	}
	public List<String> getOptionForQuestion(Integer id) {
		// TODO Auto-generated method stub
		return optionRepo.getOptionForQuestion(id);
	}
	public List<Integer> getAns(Integer id) {
		// TODO Auto-generated method stub
		return optionRepo.getAns(id);
	}

}
