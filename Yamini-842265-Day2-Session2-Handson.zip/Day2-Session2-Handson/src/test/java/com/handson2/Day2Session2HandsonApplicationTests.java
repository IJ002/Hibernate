package com.handson2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day2Session2HandsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
