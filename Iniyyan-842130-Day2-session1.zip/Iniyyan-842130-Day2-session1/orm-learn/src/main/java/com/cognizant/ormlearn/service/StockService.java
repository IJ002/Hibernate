package com.cognizant.ormlearn.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.Stock;
import com.cognizant.ormlearn.repository.StockRepository;
@Service
public class StockService {
	@Autowired
    public StockRepository stockRepository;
	public List<Stock> getAll(Integer month,String code){
		 return stockRepository.findByDate( month,code);
		
	}
	public List<Stock> getGoogleTop(Float f,String code) {
		// TODO Auto-generated method stub
	
		return stockRepository.findByStockPrice(f,code);
	}
	public List<Stock> getTopVolume() {
		// TODO Auto-generated method stub
		return stockRepository.findByTopVolume();
	}
	public List<Stock> getLowNetflix() {
		// TODO Auto-generated method stub
		return stockRepository.findByLowNet();
	}
}
