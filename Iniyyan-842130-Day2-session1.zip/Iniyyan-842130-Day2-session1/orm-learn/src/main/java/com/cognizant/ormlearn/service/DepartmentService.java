package com.cognizant.ormlearn.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.Department;
import com.cognizant.ormlearn.repository.DepartmentRepository;

@Service
public class DepartmentService {
  @Autowired
	public DepartmentRepository departmentRepository;
  @Transactional
  public Department get(Integer id) {
	  Optional<Department> result = departmentRepository.findById(id);
	  return result.get();
  }
  @Transactional
  public void save(Department dept) {
	 departmentRepository.save(dept);
  }
}
