package com.ormlearn.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table
public class Stock {

	@Id
	@GeneratedValue
	@Column(name = "st_id")
	private Integer id;
	@Column(name = "st_code")
	private String code;
	@Column(name = "st_date")
	@Temporal(TemporalType.DATE)
	private Date date;
	@Column(name = "st_open", columnDefinition = "decimal", precision = 10, scale = 2)
	private Float open;

	public Stock() {
		super();
	}

	@Column(name = "st_close", columnDefinition = "decimal", precision = 10, scale = 2)
	private Float close;
	@Column(name = "st_volume", columnDefinition = "decimal")
	private Long volume;

	@Override
	public String toString() {
		return "Stock [id=" + id + ", code=" + code + ", date=" + date + ", open=" + open + ", close=" + close
				+ ", volume=" + volume + "]";
	}

}
