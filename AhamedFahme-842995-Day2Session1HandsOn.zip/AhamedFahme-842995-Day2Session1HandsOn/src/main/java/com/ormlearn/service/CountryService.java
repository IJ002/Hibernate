package com.ormlearn.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ormlearn.model.Country;
import com.ormlearn.repository.CountryRepository;

@Service
public class CountryService {

	@Autowired
	CountryRepository countryRepo;

	@Transactional
	public List<Country> findCountryMatchingString(String exp) {

		return countryRepo.findByNameContaining(exp);
	}

	@Transactional
	public List<Country> findCountryMatchingStringOrderByName(String exp) {

		return countryRepo.findByNameContainingOrderByName(exp);
	}

	@Transactional
	public List<Country> countryStartsWith(String exp) {

		return countryRepo.findByNameStartingWith(exp);
	}

}
