package com.main;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.model.Student;

public class Main {

	private static SessionFactory sessionFactory;

	public static void main(String[] args) {

		Student student = new Student("Ramesh", "Fadatare", "rameshfadatare@javaguides.com");
		Student student1 = new Student("John", "Cena", "john@javaguides.com");
		Transaction transaction = null;
		sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		session.save(student);
		session.save(student1);
		transaction.commit();
		
		
		Session session2 = sessionFactory.openSession();
		transaction = session2.beginTransaction();
		List<Student> studentList = session2.createQuery("from Student", Student.class).list();
		studentList.forEach(stuObj->System.out.println(stuObj));
		
		Student object = session2.get(Student.class, 2);
		System.out.println(object);
		session2.delete(object);
		transaction.commit();
		
	}

}
