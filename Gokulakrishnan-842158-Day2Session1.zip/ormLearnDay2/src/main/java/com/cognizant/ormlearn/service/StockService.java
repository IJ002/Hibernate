package com.cognizant.ormlearn.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.Stocks;
import com.cognizant.ormlearn.repository.StockRepository;

@Service
public class StockService {

	@Autowired
	StockRepository stockRepository;

	@SuppressWarnings("deprecation")
	public List<Stocks> findAllSeptember() {
		return stockRepository.findAllSeptember();
	}

	public List<Stocks> googleQuery() {
		return stockRepository.googleQuery();
	}

	public List<Stocks> topThreeQuery() {
		return stockRepository.topThreeQuery();
	}

	public List<Stocks> bottomThreeQuery() {
		return stockRepository.bottomThreeQuery();
	}

}
