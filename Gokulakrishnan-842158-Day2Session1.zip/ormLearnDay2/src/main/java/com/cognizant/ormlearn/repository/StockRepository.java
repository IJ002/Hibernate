package com.cognizant.ormlearn.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.ormlearn.model.Stocks;

@Repository
public interface StockRepository extends JpaRepository<Stocks, Integer> {

	@Query(value = "select * from stocks where MONTH(date)=9 and Stock='FB'", nativeQuery = true)
	public List<Stocks> findAllSeptember();

	@Query(value = "select * from stocks where Stock='GOOGLE' and Open>1250 and Close > 1250", nativeQuery = true)
	public List<Stocks> googleQuery();

	@Query(value = "select * from stocks order by volume desc limit 3", nativeQuery = true)
	public List<Stocks> topThreeQuery();

	@Query(value = "select * from stocks where Stock='YAHOO' order by volume limit 3", nativeQuery = true)
	public List<Stocks> bottomThreeQuery();
}
