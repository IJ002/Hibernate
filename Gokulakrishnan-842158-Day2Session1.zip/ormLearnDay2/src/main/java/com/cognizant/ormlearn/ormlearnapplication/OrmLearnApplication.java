package com.cognizant.ormlearn.ormlearnapplication;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.ormlearn.model.Department;
import com.cognizant.ormlearn.model.Employee;
import com.cognizant.ormlearn.model.Skill;
import com.cognizant.ormlearn.model.Stocks;
import com.cognizant.ormlearn.service.DepartmentService;
import com.cognizant.ormlearn.service.EmployeeService;
import com.cognizant.ormlearn.service.SkillsService;
import com.cognizant.ormlearn.service.StockService;

@SpringBootApplication
@EntityScan(basePackages = "com.cognizant.ormlearn.model")
@ComponentScan(basePackages = "com.cognizant.ormlearn.service")
@EnableJpaRepositories(basePackages = "com.cognizant.ormlearn.repository")
public class OrmLearnApplication implements CommandLineRunner {

	@Autowired
	EmployeeService empService;
	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);

	@Autowired
	StockService stockService;

	@Autowired
	SkillsService skillService;

	@Autowired
	DepartmentService departmentService;

	public static void main(String[] args) {
		SpringApplication.run(OrmLearnApplication.class, args);
	}

	@Override

	public void run(String... args) throws Exception {


		Scanner sc = new Scanner(System.in);

		List<Stocks> stocks = stockService.findAllSeptember();

		stocks.forEach(e -> {
			System.out.println(e);
		});

		List<Stocks> googleQuery = stockService.googleQuery();
		for (Stocks stock : googleQuery) {
			System.out.println(stock);
		}

		List<Stocks> topThree = stockService.topThreeQuery();
		for (Stocks stock : topThree) {
			System.out.println(stock);
		}
		List<Stocks> bottomThree = stockService.bottomThreeQuery();
		for (Stocks stock : bottomThree) {
			System.out.println(stock);
		}

		Employee employee = testUpdateEmployee();
		empService.save(employee);

		testGetDepartment();

		fetchingEmployeeAlongWithSkills(employee);

		AddSkilltoEmployee();
		
		testAddEmployee();
		
		testPermanentEmployee();
	}

	private void testAddEmployee() throws ParseException {
		LOGGER.debug("insert into employee values(?,?,?,?,?)");
		Employee emp = new Employee("ABC", 1000, true, new SimpleDateFormat("yyyy-mm-dd").parse("1999-11-12"),
				departmentService.get(2));
		empService.addEmployee(emp);
		LOGGER.info(emp.toString());
	}

	private Employee testUpdateEmployee() {
		LOGGER.debug("update employee set department=? where id=?");
		Employee employee = empService.get(4);
		employee.setDepartment(departmentService.get(2));
		empService.save(employee);
		LOGGER.info("Updated employee" + employee);
		return employee;
	}

	private void testGetDepartment() {
		Department department = departmentService.get(2);
		System.err.println(department.getEmployeeList());
	}

	private void fetchingEmployeeAlongWithSkills(Employee employee) {
		Employee employee2 = empService.get(2);
		System.err.println(employee2.getSkillList());
		LOGGER.debug("Skills:{}", employee.getSkillList());
	}

	private void AddSkilltoEmployee() {
		Employee employee3 = empService.get(2);
		Skill skill = skillService.get(2);
		employee3.getSkillList().add(skill);
		empService.save(employee3);
		System.out.println(employee3.getSkillList());
	}

	private void testGetemployee() {
		LOGGER.info("Start");

		Employee employee = empService.get(1);

		LOGGER.debug("Employee:{}", employee);

		LOGGER.debug("Department:{}", employee.getDepartment());

		LOGGER.info("End");
	}

	private void testPermanentEmployee() {
		LOGGER.info("Start");

		List<Employee> permanentEmployees = empService.getAllPermanentEmployees();

		LOGGER.debug("Employee:{}", permanentEmployees);
		permanentEmployees.forEach(e -> {
			System.out.println(e);
		});

		LOGGER.info("End");
	}
	
}
