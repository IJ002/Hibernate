package com.example.ormlearn.service;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ormlearn.OrmLearnApplication;
import com.example.ormlearn.model.Employee;
import com.example.ormlearn.model.Skill;
import com.example.ormlearn.repository.SkillRepository;

@Service
public class SkillService {
	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);

	@Autowired
	SkillRepository skillRepo;
	
	@Transactional
	public void addEmployee(Skill skill) {

	skillRepo.save(skill);

	}
	@Transactional

	public Skill get(int id) {

	LOGGER.info("BEGIN");

	return skillRepo.findById(id).get();

	}
	@Transactional

	public void save(Skill skill) {

	LOGGER.info("Start");

	skillRepo.save(skill);

	LOGGER.info("End");

	}
}
