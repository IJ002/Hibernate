package com.cognizant.service;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.Demo.ApplicationDemo;
import com.cognizant.model.Question;
import com.cognizant.model.User;
import com.cognizant.repository.QuestionRepository;
import com.cognizant.repository.UserRepository;

@Service
public class QuestionService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationDemo.class);

	@Autowired
	QuestionRepository repo;

	@Transactional
	public List<Question> getAllQuestions() {

		return repo.getAllQuestions();
	}

}
