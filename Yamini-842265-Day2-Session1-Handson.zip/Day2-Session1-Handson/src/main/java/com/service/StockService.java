package com.service;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Stock;
import com.repository.StockRepository;

@Service
public class StockService {

	@Autowired
	StockRepository stockRepo;

	public List<Stock> getCodeAndDateStock(String code,Date date){
		return stockRepo.findByCodeAndDateAfter(code, date);
	}
	public List<Stock> getCodeAndDateStockBet(String code,Date date1,Date date2){
		return stockRepo.findByCodeAndDateBetween(code, date1, date2);
	}

	public List<Stock> getCodeAndStockPrice(String code,Float close) {
		// TODO Auto-generated method stub
		return stockRepo.findByCodeAndCloseAfter(code, close);
	}
	
	public List<Stock> getTopThreeRecordsOfVoume() {
		// TODO Auto-generated method stub
		return stockRepo.findTop3ByOrderByVolumeDesc();
	}
	public List<Stock> getTopThreeRecordsOfStock(String code) {
		// TODO Auto-generated method stub
		return stockRepo.findTop3ByCodeOrderByCloseAsc(code);
	}
}
