package com.handson2;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Service;

import com.exception.CountryNotFoundException;
import com.model.Country;
import com.model.Department;
import com.model.Employee;
import com.model.Skill;
import com.model.Stock;
import com.service.CountryService;
import com.service.DepartmentService;
import com.service.EmployeeService;
import com.service.SkillService;
import com.service.StockService;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.example.ormlearn.repository")
@ComponentScan("com.example.ormlearn")

public class Day2Session1HandsonApplication implements CommandLineRunner {

	@Autowired
	CountryService service;
	@Autowired
	EmployeeService empService;
	@Autowired
	StockService stockService;
	@Autowired
	DepartmentService departmentService;
	@Autowired
	SkillService skillService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(Day2Session1HandsonApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(Day2Session1HandsonApplication.class, args);
		LOGGER.info("Inside main");
	}


	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("spring app");
		testGetAllCountries();


		getAllCountriesTest();

		service.addCountry(new Country("A", "AAAAA"));

		System.err.println("Added country:" + service.getCountry("A"));

		service.updateCountry("A", "aaaaa");

		System.err.println("Updateds country:" + service.getCountry("A"));

		service.deleteCountry("A");
		try {
			System.err.println("Deleted country:" + service.getCountry("A"));
		} catch (Exception e) {
			// TODO: handle exception
			System.err.println(e);
		}

		
		List<Country> countryMatchingString = service.findCountryMatchingString("aa");

		countryMatchingString.forEach(e -> System.err.println(e));

		List<Country> countryMatchingStringOrderByName = service.findCountryMatchingStringOrderByName("aa");

		countryMatchingStringOrderByName.forEach(e -> System.err.println(e));


		List<Country> countryStartsWith = service.countryStartsWith("a");//county name based on the starting letter

		countryStartsWith.forEach(e -> System.err.println(e));
		
		System.out.println("Stock details of Facebook in the month of September 2019.");
		List<Stock> dateStock = stockService.getCodeAndDateStock("FB", new SimpleDateFormat("yyyy-MM-dd").parse("2019-09-01"));

		List<Stock> dateStockBet = stockService.getCodeAndDateStockBet("FB", new SimpleDateFormat("yyyy-MM-dd").parse("2019-09-02"),
				new SimpleDateFormat("yyyy-MM-dd").parse("2019-10-01"));
		System.out.println(dateStock);
		dateStockBet.forEach(e -> System.err.println(e));
		
		System.out.println("Stock price of google price greater than 1250");
		
		List<Stock> codeAndStockPrice = stockService.getCodeAndStockPrice("GOOGLE", 1250.00F);
		
		codeAndStockPrice.forEach(e->System.err.println(e));
		
		System.out.println("Top 3 dates which had highest volume of transactions");
		
		List<Stock> topThreeRecordsOfVoume = stockService.getTopThreeRecordsOfVoume();
		
		topThreeRecordsOfVoume.forEach(e->System.err.println(e));
		
		System.out.println("Identify three dates when Netflix stocks were the lowest");
		
		List<Stock> topThreeRecordsOfStock = stockService.getTopThreeRecordsOfStock("NETFLX");
		
		topThreeRecordsOfStock.forEach(e->System.err.println(e));	
		testGetemployee();
	
		testAddEmployee();
		
		Employee employee = testUpdateEmployee();
		empService.save(employee);
		testGetDepartment();
		
		fetchingEmployeeAlongWithSkills(employee);
		
		AddSkilltoEmployee();
		
	}

	private void testAddEmployee() throws ParseException {
		LOGGER.debug("insert into employee values(?,?,?,?,?)");
		Employee emp=new Employee("ABCD", 100, true, new SimpleDateFormat("yyyy-mm-dd").parse("1999-06-27"), departmentService.get(2));
		empService.addEmployee(emp);
		LOGGER.info(emp.toString());
	}

	private Employee testUpdateEmployee() {
		LOGGER.debug("update employee set department=? where id=?");
		Employee employee = empService.get(4);
		employee.setDepartment(departmentService.get(2));
		empService.save(employee);
		LOGGER.info("Updated employee"+employee);
		return employee;
	}

	private void testGetDepartment() {
		Department department = departmentService.get(2);
		System.err.println(department.getEmployeeList());
	}

	private void fetchingEmployeeAlongWithSkills(Employee employee) {
		Employee employee2 = empService.get(2);
		System.err.println(employee2.getSkillList());
		LOGGER.debug("Skills:{}", employee.getSkillList());
	}

	private void AddSkilltoEmployee() {
		Employee employee3 = empService.get(2);
		Skill skill = skillService.get(2);
		employee3.getSkillList().add(skill);
		empService.save(employee3);
		System.out.println(employee3.getSkillList());
	}

	private void testGetemployee() {
		LOGGER.info("Start");

		Employee employee = empService.get(1);

		LOGGER.debug("Employee:{}", employee);

		LOGGER.debug("Department:{}", employee.getDepartment());

		LOGGER.info("End");
	}
	private void testGetAllCountries() {
		List<Country> allCountries = service.getAllCountries();
		allCountries.forEach(e -> System.err.println(e));
		LOGGER.info("Start");

		List<Country> countries = service.getAllCountries();

		LOGGER.debug("countries={}", countries);

		LOGGER.info("End");
	}

	private void getAllCountriesTest() {

		LOGGER.info("Start");

		Country country = null;
		try {
			country = service.findCountryByCode("IN");
		} catch (CountryNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		LOGGER.debug("Country:{}", country);
		System.err.println(country);

		LOGGER.info("End");

	}

}
