package com.example.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.model.Employee;

@Repository 
public interface EmployeeRepo extends JpaRepository<Employee, Integer>{

	public List<Employee> findAll();

	@SuppressWarnings("unchecked")
	public Employee save(Employee country);

	@Query(value="SELECT e FROM Employee e left join fetch e.department d left join fetch e.skillList WHERE e.permanent = 1")
	public List<Employee> getAllPermanentEmployees();
	
}
