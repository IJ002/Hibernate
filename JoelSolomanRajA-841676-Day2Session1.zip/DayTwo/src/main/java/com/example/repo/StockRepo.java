package com.example.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.model.Stocks;

@Repository
public interface StockRepo extends JpaRepository<Stocks, Integer>{

	@Query(value = "select * from stocks where MONTH(date)=9 and Stock='FB'", nativeQuery = true)
	public List<Stocks> findAllSeptember();

	@Query(value = "select * from stocks where Stock='GOOGL' and Open>1250 and Close > 1250", nativeQuery = true)
	public List<Stocks> googleQuery();

	@Query(value = "select * from stocks order by volume desc limit 3", nativeQuery = true)
	public List<Stocks> topThreeQuery();

	@Query(value = "select * from stocks where Stock='NFLX' order by volume limit 3", nativeQuery = true)
	public List<Stocks> bottomThreeQuery();
	
}
