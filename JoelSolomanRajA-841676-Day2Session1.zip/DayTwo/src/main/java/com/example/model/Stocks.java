package com.example.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Stocks {

	@Id
	@GeneratedValue
	@Column(name = "stock_id")
	private Integer id;

	@Column(name = "Date")
	private Date date;
	@Column(name = "Stock")
	private String stock;
	@Column(name = "Open", columnDefinition = "decimal", precision = 4, scale = 3)
	private Float open;
	@Column(name = "Close", columnDefinition = "decimal", precision = 4, scale = 3)
	private Float close;
	@Column(name = "Volume")
	private int volume;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getStock() {
		return stock;
	}

	public void setStock(String stock) {
		this.stock = stock;
	}

	public Float getOpen() {
		return open;
	}

	public void setOpen(Float open) {
		this.open = open;
	}

	public Float getClose() {
		return close;
	}

	public void setClose(Float close) {
		this.close = close;
	}

	public int getVolume() {
		return volume;
	}

	public void setVolume(int volume) {
		this.volume = volume;
	}

	@Override
	public String toString() {
		return "Stocks [id=" + id + ", date=" + date + ", stock=" + stock + ", open=" + open + ", close=" + close
				+ ", volume=" + volume + "]";
	}
	
}
