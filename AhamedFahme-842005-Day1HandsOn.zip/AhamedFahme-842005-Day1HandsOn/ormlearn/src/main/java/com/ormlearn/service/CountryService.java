package com.ormlearn.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ormlearn.exception.CountryNotFoundException;
import com.ormlearn.model.Country;
import com.ormlearn.repository.CountryRepository;

@Service
public class CountryService {

	@Autowired
	CountryRepository countryRepo;
	//Hands on 1
	@Transactional
	public List<Country> getAllCountries() {
		return countryRepo.findAll();
	}
	//Hands on 6
	@Transactional
	public Country findCountryByCode(String countryCode) throws CountryNotFoundException {
		Optional<Country> result = countryRepo.findById(countryCode);
		if (!result.isPresent())
			throw new CountryNotFoundException("Choose other country!");
		return result.get();

	}
	//Hands on 7
	@Transactional
	public void addCountry(Country country) {
		countryRepo.save(country);
	}
	//hands on 8
	@Transactional
	public void updateCountry(String code, String name) {

		Optional<Country> country = countryRepo.findById(code);
		Country country2 = country.get();
		country2.setName(name);
	}
	@Transactional
	public Country getCountry(String code) {
		return countryRepo.findById(code).get();
	}
	//Hands on 9
	@Transactional
	public void deleteCountry(String code) {
		countryRepo.deleteById(code);
	}

}
