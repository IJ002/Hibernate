package com.ormlearn;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.ormlearn.exception.CountryNotFoundException;
import com.ormlearn.model.Country;
import com.ormlearn.service.CountryService;

@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.ormlearn.repository")
@ComponentScan("com.ormlearn")
public class OrmLearnApplication implements CommandLineRunner {

	@Autowired
	CountryService service;
	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(OrmLearnApplication.class, args);
		LOGGER.info("Inside main");
	}

	@Override
	public void run(String... args) throws Exception {
		testGetAllCountries();//Hands on 1
		getAllCountriesTest();//Hands on 6
		testAddCountry();//Hands on 7
		testUpdateCountry();//Hands on 8
		testDeleteCountry();//Hands on 9

	}
	//Hands on 1
	private void testGetAllCountries() {
		LOGGER.info("Getting Countries List");
		LOGGER.info("Start");
		List<Country> countries = service.getAllCountries();
		countries.forEach(e -> System.err.println(e));
		LOGGER.debug("countries={}", countries);
		LOGGER.info("End");
	}
	//Hands on 6
	private void getAllCountriesTest() {
		LOGGER.info("Start");
		Country country = null;
		try {
			country = service.findCountryByCode("IN");
		} catch (CountryNotFoundException e) {
			e.printStackTrace();
		}
		LOGGER.debug("Country:{}", country);
		System.err.println(country);
		LOGGER.info("End");
	}
	//Hands on 7
	public void testAddCountry() {
		service.addCountry(new Country("XX", "XXX"));
		System.err.println("Added country:" + service.getCountry("XX"));
		
	}
	//Hands on 8
	public void testUpdateCountry() {
		service.updateCountry("XX", "XXXX");
		System.err.println("Updated country:" + service.getCountry("XX"));
		
	}
	//Hands on 9
	public void testDeleteCountry()
	{
		service.deleteCountry("XX");
		try {
			System.err.println("Deleted country:" + service.getCountry("XX"));
		} catch (Exception e) {
			System.err.println("Country Deleted");
		}
		
	}

}
