package com.ormlearn.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ormlearn.Model.Employee;
import com.ormlearn.Model.Skill;
import com.ormlearn.Repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;
	private final static Logger LOGGER = LoggerFactory.getLogger(EmployeeService.class);
	private Employee employee;

	@Transactional
	public Employee get(int id) {
		LOGGER.info("Start");
		return employeeRepository.findById(id).get();
	}

	@Transactional
	public void addEmployee(Employee employee) {
		LOGGER.info("start");
		employeeRepository.save(employee);
		LOGGER.info("end");
	}

	@Transactional
	public void updateEmployee() {
		employee = this.get(1);
		employee.setName("bharani");
		employeeRepository.save(employee);
	}

	@Transactional
	public void addSkill() {
		employee = this.get(4);
		Skill skill = new Skill();
		skill.setId(1);
		Set<Skill> set = new HashSet<>();
		set.add(skill);
		employee.setSkillList(set);
		employeeRepository.save(employee);
	}

	public void testGetPermanentEmployee() {
		LOGGER.info("start");
		List<Employee> employees = employeeRepository.getAllPermanentEmployee();
		LOGGER.debug("Permanent Employees:{}", employees);
		employees.forEach(e -> LOGGER.debug("Skills:{}", e.getSkillList()));
		LOGGER.info("End");
	}
	
	public void testAvgSalary() {
		LOGGER.info("start");
		double averageSalary = employeeRepository.getAverageSalary();
		LOGGER.debug("Average Salary:{}", averageSalary);
		LOGGER.info("End");
	}
	
	public void testGetNaviveEmployee() {
		LOGGER.info("start");
		List<Employee> employees = employeeRepository.getAllEmployeesNative();
		LOGGER.debug("Permanent Employees:{}", employees);
		LOGGER.info("End");
	}

}
