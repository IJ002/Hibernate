package com.ormlearn.Application;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import com.ormlearn.Service.DepartmentService;
import com.ormlearn.Service.EmployeeService;
import com.ormlearn.Model.Department;
import com.ormlearn.Model.Employee;

@SpringBootApplication
@EnableJpaRepositories(basePackages = "com.ormlearn.Repository")
@EntityScan("com.ormlearm.Model")
@ComponentScan(basePackages="com.ormlearn")
public class OrmLearnApplication {

	private static EmployeeService employeeService;
	private static DepartmentService departmentService;
	private final static Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);

	public static void main(String[] args) throws ParseException {
		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
		employeeService = context.getBean(EmployeeService.class);
		//employeeService.testGetPermanentEmployee();
		//employeeService.testAvgSalary();
		
		departmentService = context.getBean(DepartmentService.class);
	}

	private static void testAddEmployee() throws ParseException {
		Employee employee = new Employee();
		Department department = new Department();
		department.setId(1);
		employee.setName("Vinod");
		employee.setPermanent(true);
		employee.setDateOfBirth(new SimpleDateFormat("yyyy-mm-dd").parse("1999-06-02"));
		employee.setSalary(120000.02);
		employee.setDepartment(department);
		employeeService.addEmployee(employee);
	}

		private static void testGet() {
		System.out.println(employeeService.get(1));
	}

	
	private static void testGetEmployee() {
		LOGGER.info("Start");
		Employee employee = employeeService.get(4);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.debug("Department:{}", employee.getDepartment());
		LOGGER.debug("{}",employee.getSkillList());
		System.out.println(employee.getSkillList());
		LOGGER.info("End");

	}
	
	private static void testUpdateEmployee() {
		employeeService.updateEmployee();
	}
	
	private static void testGetDepartment() {
		LOGGER.info("start");
		List<Department> department = departmentService.getDepartment();
		LOGGER.info("{}", department);
		LOGGER.info("{}",department.get(0).getEmployee());
	}
	
	private static void testAddSkillToEmployee() {
		LOGGER.info("start");
		employeeService.addSkill();
		LOGGER.info("end");
	}
	
	
}
