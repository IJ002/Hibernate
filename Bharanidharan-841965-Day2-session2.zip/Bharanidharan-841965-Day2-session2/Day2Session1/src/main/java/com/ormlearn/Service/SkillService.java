package com.ormlearn.Service;

import org.springframework.stereotype.Service;

@Service
public class SkillService {


}
