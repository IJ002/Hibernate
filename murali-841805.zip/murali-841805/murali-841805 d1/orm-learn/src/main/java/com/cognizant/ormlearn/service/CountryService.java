package com.cognizant.ormlearn.service;

import java.util.List;
import java.util.Optional;

import javax.print.attribute.standard.RequestingUserName;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.ormlearn.exception.CountryNotFoundException;
import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.repository.CountryRepository;

@Service
public class CountryService {
	@Autowired
     CountryRepository countryRepository;
	@Transactional
	public Country save(Country country) {

		return countryRepository.save(country);
	}
   
	public List<Country> getAllCountries() {
		// TODO Auto-generated method stub
		 return countryRepository.findAll();
	}

	public Country findCountryByCode(String countryCode) throws CountryNotFoundException   {
		// TODO Auto-generated method stub
		Optional<Country> result = countryRepository.findById(countryCode);
		 if(!result.isPresent()) {
			   throw new CountryNotFoundException("Country not Found");
		   }
		   Country country = result.get();
		   return country;
	}

	public void deleteCountry(String Id) {
		// TODO Auto-generated method stub
      countryRepository.deleteById(Id);
	}
}
