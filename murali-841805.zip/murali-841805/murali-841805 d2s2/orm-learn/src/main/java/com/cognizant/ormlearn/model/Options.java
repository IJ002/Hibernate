package com.cognizant.ormlearn.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table
public class Options {
        @Id
        @Column(name = "op_id")
        private Integer id;
        @Column(name = "op_score")
        private double score;
        @Column(name = "op_text")
        private String text;
        @Column(name = "op_qt_id")
        private int questionId;
		@Override
		public String toString() {
			return "Options [id=" + id + ", score=" + score + ", text=" + text + "]";
		}
		public Integer getId() {
			return id;
		}
		public void setId(Integer id) {
			this.id = id;
		}
		public double getScore() {
			return score;
		}
		public void setScore(double score) {
			this.score = score;
		}
		public String getText() {
			return text;
		}
		public void setText(String text) {
			this.text = text;
		}
		
}