package com.cognizant.ormlearn.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.Question;
import com.cognizant.ormlearn.repository.QuestionRepository;

@Service
public class QuestionService {
@Autowired
public QuestionRepository questionRepository;
public List<Question> getAll(){
	return questionRepository.findAll();
}
}
