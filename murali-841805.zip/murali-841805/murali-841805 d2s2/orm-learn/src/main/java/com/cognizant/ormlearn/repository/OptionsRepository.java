package com.cognizant.ormlearn.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.ormlearn.model.Options;
@Repository
public interface OptionsRepository extends JpaRepository<Options, Integer> {
    @Query(value = "select * from options where op_qt_id = ?1",nativeQuery = true)
	List<Options> getByQuesId(Integer id);

}
