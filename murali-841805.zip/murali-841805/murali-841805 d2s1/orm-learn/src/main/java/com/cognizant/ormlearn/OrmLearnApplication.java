package com.cognizant.ormlearn;

import java.util.Date;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.ormlearn.model.Department;
import com.cognizant.ormlearn.model.Employee;
import com.cognizant.ormlearn.model.Skill;
import com.cognizant.ormlearn.service.CountryService;
import com.cognizant.ormlearn.service.DepartmentService;
import com.cognizant.ormlearn.service.EmployeeService;
import com.cognizant.ormlearn.service.SkillService;
import com.cognizant.ormlearn.service.StockService;
@ComponentScan(basePackages ="com")
@EnableJpaRepositories("com.cognizant.ormlearn.repository")
@SpringBootApplication
public class OrmLearnApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);
	private static CountryService countryService;
    private static StockService stockService;
    private static EmployeeService employeeService;
    private static DepartmentService departmentService;
    private static SkillService skillService;
    private static Department department;

	public static void main(String[] args) {
	
		ApplicationContext context =SpringApplication.run(OrmLearnApplication.class, args);
		countryService = context.getBean(CountryService.class);
		stockService =context.getBean(StockService.class);
		employeeService =context.getBean(EmployeeService.class);
		departmentService =context.getBean(DepartmentService.class);
		skillService =context.getBean(SkillService.class);
		testGetEmployee();
		testAddEmployee();
		testUpdateEmployee();
		testAddSkillToEmployee();
		testGetDepartment();
		 
	}
	private static void testGetEmployee() {

		LOGGER.info("Start");

		Employee employee = employeeService.get(1);

		LOGGER.debug("Employee:{}", employee);

		LOGGER.debug("Department:{}", employee.getDepartment());

		LOGGER.info("End");

		}
	private static void testAddSkillToEmployee() {
		// TODO Auto-generated method stub
		LOGGER.info("Start");

		Employee employee = employeeService.get(1);
		Set<Skill> skillList = employee.getSkillList();
		Skill s = skillService.get(3);
		skillList.add(s);
		employee.setSkillList(skillList);
		LOGGER.debug("Employee:{}",employee);
		employeeService.save(employee);
		LOGGER.info("End");
		
	}
	
	private static void testUpdateEmployee() {
		// TODO Auto-generated method stub
		LOGGER.info("Start1");
		Employee emp = employeeService.get(4);
		emp.setDepartment(department);
		LOGGER.debug("Employee:", emp);
		employeeService.save(emp);
		LOGGER.info("End");
		
	}
	private static void testAddEmployee() {
		// TODO Auto-generated method stub
		LOGGER.info("Start2");

		Employee emp = new Employee();
		emp.setId(5);
		emp.setName("Iniyyan");
		emp.setSalary(50000);
		emp.setPermanent(true);
		emp.setDateOfBirth(new Date());
		emp.setDepartment(department);
		LOGGER.debug("Employee:", emp);
		employeeService.save(emp);
		LOGGER.info("End");
	}
	private static void testGetDepartment() {
		// TODO Auto-generated method stub
		LOGGER.info("Start");
		Department dept = departmentService.get(1);
		LOGGER.debug("Employee:{}",dept.getEmployeeList());
	
		LOGGER.info("End");
		
	}
	

}
