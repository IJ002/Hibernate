package com.cognizant.ormlearn.ormlearnapplication;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.ormlearn.model.Question;
import com.cognizant.ormlearn.model.User;
import com.cognizant.ormlearn.service.QuestionService;
import com.cognizant.ormlearn.service.UserService;

@SpringBootApplication
@EntityScan(basePackages = "com.cognizant.ormlearn.model")
@ComponentScan(basePackages = "com.cognizant.ormlearn.service")
@EnableJpaRepositories(basePackages = "com.cognizant.ormlearn.repository")
public class OrmLearnApplication implements CommandLineRunner {

	@Autowired
	UserService service;

	@Autowired
	QuestionService questionService;

	public static void main(String[] args) {
		SpringApplication.run(OrmLearnApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		testUserDetails();
		testQuestionDetails();

	}

	public void testUserDetails() {

		List<User> users = service.getAllUsers();

		for (User user : users) {
			System.out.println(user);
		}
	}

	public void testQuestionDetails() {
		List<Question> questions = questionService.getAllQuestions();

		questions.forEach(question -> {
			System.out.println(question);
		});

	}

}
