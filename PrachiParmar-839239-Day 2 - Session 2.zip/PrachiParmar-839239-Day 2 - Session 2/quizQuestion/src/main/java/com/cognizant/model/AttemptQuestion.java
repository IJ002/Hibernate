package com.cognizant.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "attempt_question")
@Table(name = "attempt_question")
public class AttemptQuestion {

	@Column(name = "aq_id")
	@Id
	private Integer id;
	@Column(name = "aq_at_id")
	private Integer attemptId;
	@Column(name = "aq_qt_id")
	private Integer qId;

}
