package com.ormlearn.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ormlearn.model.User;
import com.ormlearn.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	UserRepository userRepo;

	@Transactional
	public void addUser(User user) {

		userRepo.save(user);

	}

	@Transactional

	public User get(int id) {

		return userRepo.findById(id).get();

	}

	@Transactional

	public void save(User user) {

		userRepo.save(user);

	}

}
