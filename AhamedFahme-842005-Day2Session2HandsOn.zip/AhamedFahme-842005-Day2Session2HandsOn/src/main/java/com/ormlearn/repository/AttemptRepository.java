package com.ormlearn.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ormlearn.model.Attempt;

@Repository
public interface AttemptRepository extends JpaRepository<Attempt, Integer> {
	
	@Query(value="from Attempt where at_id=?1")
	public Attempt getAttempt(int userId, int attemptId);

	
}
