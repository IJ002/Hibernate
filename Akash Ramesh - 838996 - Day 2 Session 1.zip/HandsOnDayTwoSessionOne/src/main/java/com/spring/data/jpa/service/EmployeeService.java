package com.spring.data.jpa.service;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.data.jpa.HandsOnDayTwoSessionOne.HandsOnDayTwoSessionOne;
import com.spring.data.jpa.model.Employee;
import com.spring.data.jpa.repo.EmployeeRepository;

@Service
public class EmployeeService {
	private static final Logger LOGGER = LoggerFactory.getLogger(HandsOnDayTwoSessionOne.class);

	@Autowired
	EmployeeRepository empRepo;

	@Transactional
	public void addEmployee(Employee employee) {

		empRepo.save(employee);

	}

	@Transactional

	public Employee get(int id) {

		LOGGER.info("Start");

		return empRepo.findById(id).get();

	}

	@Transactional

	public void save(Employee employee) {

		LOGGER.info("Start");

		empRepo.save(employee);

		LOGGER.info("End");

	}

	public List<Employee> getAllPermanentEmployees() {
		
		return empRepo.getAllPermanentEmployees();
	}

}
