package com.spring.data.jpa.service;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.data.jpa.HandsOnDayTwoSessionOne.HandsOnDayTwoSessionOne;
import com.spring.data.jpa.model.Department;
import com.spring.data.jpa.repo.DepartmentRepository;

@Service
public class DepartmentService {
	private static final Logger LOGGER = LoggerFactory.getLogger(HandsOnDayTwoSessionOne.class);

	@Autowired
	DepartmentRepository departmentRepo;

	@Transactional
	public void addEmployee(Department department) {

		departmentRepo.save(department);

	}

	@Transactional

	public Department get(int id) {

		LOGGER.info("Start");

		return departmentRepo.findById(id).get();

	}

	@Transactional
	public void save(Department d) {

		LOGGER.info("Start");

		departmentRepo.save(d);

		LOGGER.info("End");

	}
}
