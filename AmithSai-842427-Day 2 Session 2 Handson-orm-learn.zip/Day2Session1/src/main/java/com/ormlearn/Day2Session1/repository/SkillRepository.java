package com.ormlearn.Day2Session1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ormlearn.Day2Session1.model.Skill;

public interface SkillRepository extends JpaRepository<Skill, Integer>  {

}
