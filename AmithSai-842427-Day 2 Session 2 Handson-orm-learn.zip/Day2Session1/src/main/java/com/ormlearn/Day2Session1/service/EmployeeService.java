package com.ormlearn.Day2Session1.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ormlearn.Day2Session1.model.Employee;
import com.ormlearn.Day2Session1.model.Skill;
import com.ormlearn.Day2Session1.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;
	private final static Logger logger = LoggerFactory.getLogger(EmployeeService.class);
	private Employee employee;

	@Transactional
	public Employee get(int id) {
		logger.info("Start");
		return employeeRepository.findById(id).get();
	}

	@Transactional
	public void addEmployee(Employee employee) {
		logger.info("start");
		employeeRepository.save(employee);
		logger.info("end");
	}

	@Transactional
	public void updateEmployee() {
		employee = this.get(1);
		employee.setName("Amith Sai");
		employeeRepository.save(employee);
	}

	@Transactional
	public void addSkill() {
		employee = this.get(4);
		Skill skill = new Skill();
		skill.setId(1);
		Set<Skill> set = new HashSet<>();
		set.add(skill);
		employee.setSkillList(set);
		employeeRepository.save(employee);
	}

	public void testGetPermanentEmployee() {
		logger.info("start");
		List<Employee> employees = employeeRepository.getAllPermanentEmployee();
		logger.debug("Permanent Employees:{}", employees);
		employees.forEach(e -> logger.debug("Skills:{}", e.getSkillList()));
		logger.info("End");
	}
	
	public void testAvgSalary() {
		logger.info("start");
		double averageSalary = employeeRepository.getAverageSalary();
		logger.debug("Average Salary:{}", averageSalary);
		logger.info("End");
	}
	
	public void testGetNaviveEmployee() {
		logger.info("start");
		List<Employee> employees = employeeRepository.getAllEmployeesNative();
		logger.debug("Permanent Employees:{}", employees);
		logger.info("End");
	}

}
