package com.cognizant.Demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.model.Question;
import com.cognizant.model.User;
import com.cognizant.service.QuestionService;
import com.cognizant.service.UserService;

@SpringBootApplication
@EntityScan(basePackages = "com.cognizant.model")
@ComponentScan(basePackages = "com.cognizant.service")
@EnableJpaRepositories(basePackages = "com.cognizant.repository")
public class ApplicationDemo implements CommandLineRunner {

	@Autowired
	UserService service;

	@Autowired
	QuestionService questionService;

	public static void main(String[] args) {
		SpringApplication.run(ApplicationDemo.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		UserDetailsTesting();
		QuestionDetailsTesting();

	}

	public void UserDetailsTesting() {

		List<User> users = service.getAllUsers();
		users.forEach(user -> System.out.println(user));
	}

	public void QuestionDetailsTesting() {
		List<Question> questions = questionService.getAllQuestions();
		questions.forEach(question -> System.out.println(question));

	}

}
