package com.spring.data.jpa.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.spring.data.jpa.model.Country;

@Repository
public interface CountryRepository extends JpaRepository<Country, String> {
	// HandsOnDayOne By 838996 Akash Ramesh

	public List<Country> findAll();

	public Country findByCode(String id);
	
	public Country save(Country country);
	
	public void deleteById(String id);
	
}
