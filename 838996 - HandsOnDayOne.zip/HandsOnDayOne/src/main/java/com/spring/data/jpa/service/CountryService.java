package com.spring.data.jpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.data.jpa.model.Country;
import com.spring.data.jpa.repo.CountryRepository;

@Service
public class CountryService {

	@Autowired
	CountryRepository countryRepository;
	// HandsOnDayOne By 838996 Akash Ramesh

	public List<Country> findAll() {
		return countryRepository.findAll();
	}

	public Country findById(String id) {

		return countryRepository.findByCode(id);

	}

	public void save(Country country) {

		countryRepository.save(country);
	}

	public void deleteByCode(String id) {
		countryRepository.deleteById(id);
	}

}
