package com.spring.data.jpa.service;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.data.jpa.Demo.Application;
import com.spring.data.jpa.model.Skill;
import com.spring.data.jpa.repo.SkillRepository;

@Service
public class SkillsService {
	private static final Logger LOGGER = LoggerFactory.getLogger(Application.class);

	@Autowired
	SkillRepository skillRepo;
	
	@Transactional
	public void addEmployee(Skill skill) {

	skillRepo.save(skill);

	}
	
	@Transactional
	public Skill get(int id) {

	LOGGER.info("Start");

	return skillRepo.findById(id).get();

	}
	
	@Transactional
	public void save(Skill skill) {

	LOGGER.info("Start");

	skillRepo.save(skill);

	LOGGER.info("End");

	}
}
