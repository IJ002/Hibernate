package com.spring.data.jpa.service;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.data.jpa.HandsOnDayTwoSessionTwo.Day_2_Session_2;
import com.spring.data.jpa.model.Question;
import com.spring.data.jpa.model.User;
import com.spring.data.jpa.repo.QuestionRepository;
import com.spring.data.jpa.repo.UserRepository;

@Service
public class QuestionService {
	private static final Logger LOGGER = LoggerFactory.getLogger(Day_2_Session_2.class);

	@Autowired
	QuestionRepository repo;

	@Transactional

	public List<Question> getAllQuestions() {

		return repo.getAllQuestions();
	}

}
