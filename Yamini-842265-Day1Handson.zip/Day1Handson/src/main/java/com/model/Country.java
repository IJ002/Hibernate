package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity

public class Country {

	@Id
	@Column(name = "countrycode")
	private String code;


	@Column(name = "countryname")
	private String name;


	public Country() {
		super();
	}
	
	public Country(String code , String name) {
		super();
		this.code = code;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Country [code=" + code + ", name=" + name + "]\n";
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
