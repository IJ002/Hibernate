package com.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.model.Country;


@Repository
public interface CountryRepository extends JpaRepository<Country, String> {
    public Country findByCode(String string);
    public void save(Optional<Country> update);
    public List<Country> findByNameContaining(String string);
}