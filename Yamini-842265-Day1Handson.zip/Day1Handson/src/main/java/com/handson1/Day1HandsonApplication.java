package com.handson1;
                    //DAY 1 HANDSON (YAMINI-842265)
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import com.model.Country;
import com.service.CountryService;


@SpringBootApplication
@EntityScan(basePackages = { "com" })
@ComponentScan(basePackages = { "com.cognizant.service" })
@EnableJpaRepositories(basePackages = { "com.cognizant.repository" })
public class Day1HandsonApplication implements CommandLineRunner{
	
	private static final Logger logger = LoggerFactory.getLogger(Day1HandsonApplication.class);
	@Autowired
	private CountryService countryService;
	
	public static void main(String[] args) {
		SpringApplication.run(Day1HandsonApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		 logger.info("Inside run");
		 insertFirst();

		// All Country with name
		List<Country> clist = countryService.getAllCountries();
		
		if (!clist.isEmpty()) {
			clist.forEach(e -> System.out.println(e));
		} else {
			System.out.println("No data found");
		}
		//find the country using code
		Optional<Country> findlist = countryService.findCountryByCode("B");
		if (findlist.isPresent()) {
			System.out.println( findlist.get().getCode() + "  " + findlist.get().getName());
		} else {
			System.out.println("Invalid country code");
		}

		// add 
		Country add_country = new Country("E", "EEEEEE");
		countryService.addCountry(add_country);
		List<Country> addedlist = countryService.getAllCountries();
		addedlist.forEach(e -> System.out.println(e));
		
	   //Update	
		if(countryService.findCountryByCodebyId("A")!=null)
		{
			Country tobeUpdated = new Country();
			tobeUpdated.setCode("A");   
			tobeUpdated.setName("aaaaaa"); 
			countryService.addCountry(tobeUpdated);
			
		}
		
		List<Country> updatedlist = countryService.getAllCountries();
		updatedlist.forEach(e -> System.out.println(e));
		
		
		
		// Delete
		
		countryService.deleteCountrybyCode("D");
		List<Country> afterdeletelist = countryService.getAllCountries();
		afterdeletelist.forEach(e -> System.out.println(e));

	}

	public void insertFirst() {
		

		Country A = new Country("A", "AAAAAA");
		Country B = new Country("B", "BBBBBB");
		Country C = new Country("C", "CCCCCC");
		Country D = new Country("D", "DDDDDD");

		List<Country> cList = new ArrayList<Country>();
		cList.add(A);
		cList.add(B);
		cList.add(C);
		cList.add(D);

		countryService.storeCountryDetails(cList);

	}

}
