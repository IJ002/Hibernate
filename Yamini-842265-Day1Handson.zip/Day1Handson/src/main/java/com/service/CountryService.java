package com.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.model.Country;
import com.repository.CountryRepository;
import com.exception.CountryNotFoundException;

@Service
public class CountryService {

	@Autowired
	private CountryRepository countryRepository;

	public List<Country> storeCountryDetails(List<Country> cList) {

		return countryRepository.saveAll(cList);
	}
	@Transactional(propagation = Propagation.REQUIRED)
	public List<Country> getAllCountries() {

		return countryRepository.findAll();
	}
	@Transactional(propagation = Propagation.REQUIRED)
	public Optional<Country> findCountryByCode(String countryCode) throws CountryNotFoundException
	{
		return countryRepository.findById(countryCode);
		
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public Country findCountryByCodebyId(String countryCode) throws CountryNotFoundException
	{
		return countryRepository.findByCode(countryCode);
	
	}

	@Transactional(propagation = Propagation.REQUIRED)
	public Country addCountry(Country country)
	{
		return countryRepository.save(country);
	}
	@Transactional(propagation = Propagation.REQUIRED)
	public void updateCountry(Country toUpdate) {

		countryRepository.save(toUpdate);
	}

	public void deleteCountrybyCode(String string) throws CountryNotFoundException {

		Country todelete = findCountryByCodebyId(string);
		countryRepository.delete(todelete);
	}
	public List<Country> getsuggestions(String string) {

		List<Country> slist = countryRepository.findByNameContaining(string);
		return slist;
	}

}
