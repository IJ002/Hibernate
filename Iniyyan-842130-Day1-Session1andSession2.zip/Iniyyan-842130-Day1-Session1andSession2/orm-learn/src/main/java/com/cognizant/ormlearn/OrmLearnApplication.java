package com.cognizant.ormlearn;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.service.CountryService;

import com.cognizant.ormlearn.service.exception.CountryNotFoundException;

import java.text.ParseException;
import java.util.List;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

@SpringBootApplication
@ComponentScan(basePackages ="com")
@EnableJpaRepositories("com.cognizant.ormlearn.repository")
public class OrmLearnApplication {

	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);
	private static CountryService countryService;

	public static void main(String[] args) throws CountryNotFoundException{
		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);

		countryService = context.getBean(CountryService.class);
		
		//testGetAllCountries();
		//testAddCountry();
		//testUpdateCountry();
		//getAllCountriesTest();
		//testDeleteCountry();
		//testContainingCountry();
		//testStartCountry();
		
		LOGGER.info("Inside main");
	}
	
	private static void testGetAllCountries() {

		LOGGER.info("Start");

		List<Country> countries = countryService.getAllCountries();

		LOGGER.debug("countries={}", countries);

		LOGGER.info("End");

		}
	private static void getAllCountriesTest() throws CountryNotFoundException {

		LOGGER.info("Start");

		Country country = countryService.findCountryByCode("Tu");

		LOGGER.debug("Country:{}", country);

		LOGGER.info("End");

		}
	private static void testAddCountry()  {
		Country c = new Country();
		c.setCode("Tu");
		c.setName("TamilNadu");
		countryService.addCountry(c);
	
		}
	private static void testUpdateCountry() {
		countryService.updateCountry("Tu","Telangana");
	}
	private static void testDeleteCountry() {
		countryService.deleteCountry("Tu");
	}
	private static void testContainingCountry() {
		LOGGER.info("Start"); 
		List<Country> countries = countryService.findByNameContaining("ou");
		
		LOGGER.debug("Country:{}", countries);

		LOGGER.info("End");
	}
	private static void testStartCountry() {
		LOGGER.info("Start"); 
		List<Country> countries = countryService.findByNameStartingWith("Z");
		LOGGER.debug("Country:{}", countries);

		LOGGER.info("End");
	}

}
