package com.example.ormlearn;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;

import com.example.ormlearn.service.StockService;

public class StockMain {

	@Autowired
	static private StockService stockService;

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		SpringApplication.run(OrmLearnApplication.class, args);
		System.out.println("inside stock" + new Date(2019, 9, 3));

	}

}
