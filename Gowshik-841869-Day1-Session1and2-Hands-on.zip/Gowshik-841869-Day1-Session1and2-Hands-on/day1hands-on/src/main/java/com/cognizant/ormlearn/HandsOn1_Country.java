package com.cognizant.ormlearn;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.model.Country;
import com.cognizant.service.CountryService;


// Gowshik's Day one session 1 and 2 hands on completed along with some day 2 session 1 handson
// Create db named "day1handson" 

@SpringBootApplication
@EntityScan(basePackages = { "com" })
@ComponentScan(basePackages = { "com.cognizant.service" })
@EnableJpaRepositories(basePackages = { "com.cognizant.repository" })
public class HandsOn1_Country implements CommandLineRunner {

	private static final Logger logger = LoggerFactory.getLogger(HandsOn1_Country.class);
	@Autowired
	private CountryService countryService;

	public static void main(String[] args) {
		SpringApplication.run(HandsOn1_Country.class, args);
		// logger.info("Inside Main");
	}

	// Commandline Runner
	@Override
	public void run(String... args) throws Exception {

		 logger.info("/////////////Inside run method.////////");
		System.out.println("Welcome to console");
		store();

		// get all countries name and code
		List<Country> clist = countryService.getAllCountries();

		System.out.println("-----------------------Getting all countries in db-----------------------------");
		if (!clist.isEmpty()) {
			clist.forEach(e -> System.out.println(e));
		} else {
			System.out.println("No data found");
		}

		System.out.println("-----------------------Finished----------------------------");

		// get counties using code
		Optional<Country> findlist = countryService.findCountryByCode("IN");
		System.out.println("--------------------Finding country by code-----------------------");
		if (findlist.isPresent()) {
			System.out.println("Code--->" + findlist.get().getCode() + "\nCountry--->" + findlist.get().getName());
			System.out.println("---------------Found------------------------");
		} else {
			System.out.println("Country code Not Found ");
		}

		// add new country
		Country add_country = new Country("IT", "Italy");
		System.out.println("-----------------------Adding new Country-----------------------------");
		countryService.addCountry(add_country);
		System.out.println("---------------------After Adding------------------");
		List<Country> addedlist = countryService.getAllCountries();
		addedlist.forEach(e -> System.out.println(e));
		System.out.println("--------------------Added-----------------------------------");

		// update the country details
//		System.out.println("------------------Updating US to USA united states of America-------------");
//		Optional<Country> update = countryService.findCountryByCode("US");
//		Country toUpdate = update.get();
//		toUpdate.setCode("USA");
//		toUpdate.setName("UNITED STATES OF AMERICA");
//		countryService.updateCountry(toUpdate);
//		System.out.println("---------------------After Updating-----------------------------");
//		Optional<Country> updatedlist = countryService.findCountryByCode("USA");
//		System.out.println("Code--->" + updatedlist.get().getCode() + "\nCountry--->" + updatedlist.get().getName());
//		System.out.println("---------------------Updated Successfully-----------");

		
		
		//updating the country details
		
		if(countryService.findCountryByCodebyId("US")!=null)
		{
			Country tobeUpdated = new Country();
			tobeUpdated.setCode("US");   // id cant be changed . if so then new record will be inserted 
			tobeUpdated.setName("UNITED STATES OF AMERICA (Upddated)");  // united states to United states of america
			countryService.addCountry(tobeUpdated);
			System.out.println("-----------------Updated------------------");
		}
		System.out.println("---------------------------After Updating------------------------");
		List<Country> updatedlist = countryService.getAllCountries();
		updatedlist.forEach(e -> System.out.println(e));
		
		
		
		// Delete Operation
		System.out.println("-------------Delete Operation for Japan-------------------");
		countryService.deleteCountrybyCode("JPN");
		System.out.println("---------------------After Deleting------------------");
		List<Country> afterdeletelist = countryService.getAllCountries();
		afterdeletelist.forEach(e -> System.out.println(e));
		System.out.println("-------------------------Deleted Successfully-------------------------------");

		
		// -------------HandsOn day two session One ------------------------------------------------- 
		// To search and get suggestions using the letters
		List<Country> slist = countryService.getsuggestions("i");
		System.out.println("-----------------Getting suggestion for the input 'i'----------------------------");
		slist.forEach(e -> System.out.println(e.getName()));

	}

	// Defined method to store the details
	public void store() {
		// logger.info("Inside the Store() method");

		Country c1 = new Country("IN", "India");
		Country c2 = new Country("US", "United States");
		Country c3 = new Country("AUS", "Australia");
		Country c4 = new Country("JPN", "Japan");

		List<Country> cList = new ArrayList<Country>();
		cList.add(c1);
		cList.add(c2);
		cList.add(c3);
		cList.add(c4);

		countryService.storeCountryDetails(cList);
		System.out.println("Finished inserting");
		// logger.info("Country Details has been stored\n"+storeCountryDetails);

	}

}
