package com.cognizant.service.exception;

@SuppressWarnings("serial")
public class CountryNotFoundException extends Exception {

}
