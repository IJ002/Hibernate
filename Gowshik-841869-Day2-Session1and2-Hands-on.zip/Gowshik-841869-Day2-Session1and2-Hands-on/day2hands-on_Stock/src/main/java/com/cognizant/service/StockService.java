package com.cognizant.service;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.Stock;
import com.cognizant.repository.StockRepository;

@Service
public class StockService {

	
	@Autowired
	private StockRepository stockRepository;

	public List<Stock> addStocks(List<Stock> slist) {

		return stockRepository.saveAll(slist);
	}

	public List<Stock> getfbStockbyDate(LocalDate localDate ,LocalDate localDate2) {

		return stockRepository.findBySt_DateForFB(localDate,localDate2);
	}

	public List<Stock> getAllStocks() {

		return stockRepository.findAll();
	}

	public List<Stock> getGoogleStockBasedOnPriceGreaterthan(double d) {
		return stockRepository.findByGoogleStockPriceGreatherThan(d);
	}

	public List<Stock> getTop3StocksDateByVolume() {
		//return stockRepository.findByTop3StocksDateByVolume(); 
		return stockRepository.findTop3ByOrderByStVolumeDesc(); 
	}

	public List<Stock> getNetflixTop3LowestStocksDate(String st_code) {
		//return stockRepository.findByNetflixTop3lowestStockPrice();
		return stockRepository.findTop3ByStCodeOrderByStClose(st_code);
	}

	
	
	
}
