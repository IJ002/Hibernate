package com.cognizant.ormlearn;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


import com.cognizant.model.Stock;
import com.cognizant.service.StockService;


//Gowshik's Day 2 Seesion 1 and some session2 hands-on For Stock database
//make sure localhost changed to 3307 to 3306
//set db as "day2handson"
//also do maven install before running to download packages
@SpringBootApplication
@EntityScan(basePackages = {"com"})
@ComponentScan(basePackages = {"com.cognizant.service"})
@EnableJpaRepositories(basePackages = {"com.cognizant.repository"})
public class HandsOnDay2_Country implements CommandLineRunner{
	
	private static final Logger logger =  LoggerFactory.getLogger(HandsOnDay2_Country.class);
	
	@Autowired
	private StockService stockService;
	
	
	public static void main(String[] args) {
		SpringApplication.run(HandsOnDay2_Country.class, args);
		//logger.info("Inside Main");
	}

	// Commandline Runner
	@Override
	public void run(String... args) throws Exception {

		//logger.info("/////////////Inside run method.////////");
		System.out.println("Welcome to console");
		
		//Stock Details.............................................
		System.out.println("Storing Stock Details----------------------------------------");
		storeStock();
		
		//showing all stocks
		System.out.println("-----------------------Showing all Stocks---------------------------------------");
		List<Stock> stkslist = stockService.getAllStocks();
		stkslist.forEach(e->System.out.println(e));
		
		
		//Query for  all stock details of Facebook in the month of September 2019
		System.out.println("---------------------------------Retrieving details for stock for FB in september 2019------------------------------");
		List<Stock> fblist = stockService.getfbStockbyDate(LocalDate.of(2019,9,01),LocalDate.of(2019,9,30));
		fblist.forEach(e->System.out.println(e));
		System.out.println("-----------------------------------------------Retrieved----------------------------------");
		
		
		//Query for google stocks price greater than 1250
		System.out.println("---------------------Getting  all google stock details where the stock price was greater than 1250-----------------");
		List<Stock> goglist = stockService.getGoogleStockBasedOnPriceGreaterthan(1250d);
		goglist.forEach(e->System.out.println(e));
		System.out.println("-----------------------------------------------Retrieved----------------------------------");
		
		
		//Query for top 3 stocks dates of highest volume
		System.out.println("---------------------Getting  all google stock details where the stock price was greater than 1250-----------------");
		List<Integer> idlist = new ArrayList<Integer>();
		List<Stock> toplist = stockService.getTop3StocksDateByVolume();
		toplist.forEach(e->System.out.println(e));
		System.out.println("-----------------------------------------------Retrieved----------------------------------");
		
		//Query for top 3 Netflix stocks dates of lowest stocks price
		System.out.println("---------------------Getting  all google stock details where the stock price was greater than 1250-----------------");
		List<Stock> netflist = stockService.getNetflixTop3LowestStocksDate("NFLX");
		netflist.forEach(e->System.out.println(e));
		System.out.println("-----------------------------------------------Retrieved----------------------------------");		
		
		
	}
	
	
	
	private void storeStock() {

		Stock s1 = new Stock("FB", LocalDate.of(2019,9,03) , 184.65 , 182.39, (double) 9779400);
		Stock s2 = new Stock("FB", LocalDate.of(2019,9,07) , 193.35 , 187.69, (double) 9673523);
		Stock s3 = new Stock("FB", LocalDate.of(2019,10,21) , 135.10 , 182.49, (double) 464468);
		Stock s4 = new Stock("FB", LocalDate.of(2019,11,26) , 186.60 , 184.29, (double) 1344545);
		Stock s5 = new Stock("FB", LocalDate.of(2019,12,28) , 200.70 , 189.59, (double) 6356478);
		
		Stock s6 = new Stock("GOOGL", LocalDate.of(2019,9,03) , 1214.70 , 1288.49, (double) 73573634);
		Stock s7 = new Stock("GOOGL", LocalDate.of(2019,10,03) , 1264.20 , 1222.99, (double) 345456);
		Stock s8 = new Stock("GOOGL", LocalDate.of(2019,12,03) , 1034.10 , 1252.39, (double) 9785534);
		Stock s9 = new Stock("GOOGL", LocalDate.of(2019,5,03) , 1234.40 , 1272.39, (double) 5435776);
		
		Stock s10 = new Stock("NFLX", LocalDate.of(2019,7,05) , 142.50 , 189.56, (double) 234567);
		Stock s11 = new Stock("NFLX", LocalDate.of(2019,10,02) , 1170.60 , 1177.33, (double) 765554);
		Stock s12 = new Stock("NFLX", LocalDate.of(2019,11,12) , 154.90 , 167.88, (double) 46865542);
		Stock s13 = new Stock("NFLX", LocalDate.of(2019,12,12) , 1154.90 , 1167.88, (double) 9645542);
		Stock s14 = new Stock("NFLX", LocalDate.of(2019,12,29) , 154.90 , 167.88, (double) 5865542);
		
		List<Stock> slist = new ArrayList<Stock>();
		slist.add(s1);
		slist.add(s2);
		slist.add(s3);
		slist.add(s4);
		slist.add(s5);
		slist.add(s6);
		slist.add(s7);
		slist.add(s8);
		slist.add(s9);
		slist.add(s10);
		slist.add(s11);
		slist.add(s12);
		slist.add(s13);
		slist.add(s14);
		
		stockService.addStocks(slist);
		System.out.println("-----------------Finished Adding Stock-----------------------------------------");
		
		
		
	}

	


}
