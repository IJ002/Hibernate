package com.cognizant.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cognizant.model.Stock;

public interface StockRepository extends JpaRepository<Stock, Integer>{
	
	@Query(value = "select s from Stock s where s.stCode='FB' and s.stDate >= ?1 and s.stDate <= ?2")
	public List<Stock> findBySt_DateForFB(@Param("1")LocalDate startDate , @Param("2")LocalDate endDate);

	@Query(value = "select s from Stock s where s.stCode='GOOGL' and s.stClose=?1")
	public List<Stock> findByGoogleStockPriceGreatherThan(@Param("1")double d);

//	@Query(value = "select s from Stock s order by s.stVolume desc limit 3")
//	public List<Stock> findByTop3StocksDateByVolume();
//
//	@Query(value = "select s from Stock s s.stCode='NFLX' order by s.stClose limit 3")
//	public List<Stock> findByNetflixTop3lowestStockPrice();
	
	
	public List<Stock> findTop3ByOrderByStVolumeDesc();
	
	public List<Stock> findTop3ByStCodeOrderByStClose(String st_code);

	

}
