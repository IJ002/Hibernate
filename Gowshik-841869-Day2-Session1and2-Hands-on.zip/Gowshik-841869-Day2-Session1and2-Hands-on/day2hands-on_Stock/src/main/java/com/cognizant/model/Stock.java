package com.cognizant.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Stock {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer stId;
	private String stCode;

	private LocalDate stDate;
	private Double stOpen;
	private Double stClose;
	private Double stVolume;
	public Integer getStId() {
		return stId;
	}
	public void setStId(Integer stId) {
		this.stId = stId;
	}
	public String getStCode() {
		return stCode;
	}
	public void setStCode(String stCode) {
		this.stCode = stCode;
	}
	public LocalDate getStDate() {
		return stDate;
	}
	public void setStDate(LocalDate stDate) {
		this.stDate = stDate;
	}
	public Double getStOpen() {
		return stOpen;
	}
	public void setStOpen(Double stOpen) {
		this.stOpen = stOpen;
	}
	public Double getStClose() {
		return stClose;
	}
	public void setStClose(Double stClose) {
		this.stClose = stClose;
	}
	public Double getStVolume() {
		return stVolume;
	}
	public void setStVolume(Double stVolume) {
		this.stVolume = stVolume;
	}
	public Stock(String stCode, LocalDate stDate, Double stOpen, Double stClose, Double stVolume) {
		super();
		this.stCode = stCode;
		this.stDate = stDate;
		this.stOpen = stOpen;
		this.stClose = stClose;
		this.stVolume = stVolume;
	}
	public Stock() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "stId=" + stId + ", stCode=" + stCode + ", stDate=" + stDate + ", stOpen=" + stOpen + ", stClose="
				+ stClose + ", stVolume=" + stVolume + "\n";
	}

	
}
