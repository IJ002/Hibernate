package com.cognizant.service.exception;

public class CountryNotFoundException extends Exception {

}
