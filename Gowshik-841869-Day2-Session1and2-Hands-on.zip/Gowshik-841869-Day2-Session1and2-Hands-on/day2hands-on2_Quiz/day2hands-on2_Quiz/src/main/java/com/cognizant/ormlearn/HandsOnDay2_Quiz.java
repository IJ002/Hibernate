package com.cognizant.ormlearn;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.model.Question;
import com.cognizant.service.AttemptService;
import com.cognizant.service.OptionsService;
import com.cognizant.service.QuestionService;
import com.cognizant.service.UserService;


//Gowshik's Day 2 Seesion session2 hands-on For Employee database
//make sure localhost changed to 3307 to 3306
//set db as day2handsonquiz
// also do maven install before running to download packages
@SpringBootApplication
@EntityScan(basePackages = {"com"})
@ComponentScan(basePackages = {"com.cognizant.service"})
@EnableJpaRepositories(basePackages = {"com.cognizant.repository"})
public class HandsOnDay2_Quiz implements CommandLineRunner{
	
	private static final Logger logger =  LoggerFactory.getLogger(HandsOnDay2_Quiz.class);


	
	@Autowired
	AttemptService attemptService;
	@Autowired
	QuestionService questionService;
	@Autowired
	OptionsService optionService;
	@Autowired
	UserService userService;
	
	
	public static void main(String[] args) {
		SpringApplication.run(HandsOnDay2_Quiz.class, args);
		logger.info("Inside Main");
	}

	// Commandline Runner
	@Override
	public void run(String... args) throws Exception {
		
		//Users info and questions info are in table already
		//refer scripts.sql for creating table
		testQuiz(); // method to get the attempt of one user of id 1
			
	}
	
	private void testQuiz() {
		System.out.println(attemptService.getAttempt(1, 1));

		List<Question> questions = questionService.getQuestions();

		for (Question que : questions) {
			System.out.println(que.getQuestionText());
			List<String> options = optionService.getOptionForQuestion(que.getId());
			List<Integer> ans = optionService.getAns(que.getId());
			for (int i = 0; i < options.size(); i++) {
				System.err.print(options.get(i) + "  \t");
				System.err.print(ans.get(i) + " \t");
				if (ans.get(i) != 0) {
					System.err.println(true);
				} else
					System.err.println(false);
				System.out.println();
			}
		}
	}
	
	


}
