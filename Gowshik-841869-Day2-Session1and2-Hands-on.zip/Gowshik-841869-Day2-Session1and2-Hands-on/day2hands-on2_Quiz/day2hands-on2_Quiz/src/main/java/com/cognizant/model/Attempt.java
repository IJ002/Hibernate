package com.cognizant.model;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Attempt {

	@Id
	@GeneratedValue
	@Column(name = "at_id")
	private Integer id;
	@Column(name = "at_date")
	private Date date;
	@Column(name = "at_us_id")
	private Integer userId;
	@Column(name = "at_score")
	private Double score;

	@Override
	public String toString() {
		return "Attempt [id=" + id + ", date=" + date + ", userId=" + userId + ", score=" + score + "]";
	}
}