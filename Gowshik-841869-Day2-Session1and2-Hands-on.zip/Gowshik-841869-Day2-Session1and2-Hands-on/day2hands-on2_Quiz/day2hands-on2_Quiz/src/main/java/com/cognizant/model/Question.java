package com.cognizant.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Table
@Entity
public class Question {

	@Id
	@GeneratedValue
	@Column(name = "qt_id")
	private Integer qid;
	@Column(name = "qt_text")
	private String text;

	public String getQuestionText() {
		return text;
	}

	public void setQuestionText(String questionText) {
		this.text = questionText;
	}

	public Integer getId() {
		return qid;
	}
	public Question() {
	}

}
