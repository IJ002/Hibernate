package com.cognizant.service;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.Attempt;
import com.cognizant.repository.AttemptRepository;

@Service
public class AttemptService {

	@Autowired
	AttemptRepository attemptRepo;

	public Attempt getAttempt(int userId, int attemptId) {
		return attemptRepo.getAttempt(userId, attemptId);
	}

	@Transactional
	public void addAttempt(Attempt attempt) {

		attemptRepo.save(attempt);

	}

	@Transactional

	public Attempt get(int id) {

		return attemptRepo.findById(id).get();

	}

	@Transactional

	public void save(Attempt attempt) {

		attemptRepo.save(attempt);

	}

}
