package com.cognizant.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Options {

	public Options() {	}
	@Id
	@GeneratedValue
	@Column(name = "op_id")
	private Integer id;
	@Column(name = "op_qt_id")
	private Integer questionId;
	@Column(name = "op_score")
	private Double optionScore;
	@Column(name = "op_text")
	private String optionText;
	public Integer getQuestionId() {
		return questionId;
	}
	public void setQuestionId(Integer questionId) {
		this.questionId = questionId;
	}
	public Double getOptionScore() {
		return optionScore;
	}
	public void setOptionScore(Double optionScore) {
		this.optionScore = optionScore;
	}
	public String getOptionTexts() {
		return optionText;
	}
	public void setOptionTexts(String optionText) {
		this.optionText = optionText;
	}

}
