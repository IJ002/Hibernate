package com.cognizant.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Attempt;


@Repository
public interface AttemptRepository extends JpaRepository<Attempt, Integer> {
	
	@Query(value="from Attempt where at_id=?1")
	public Attempt getAttempt(int userId, int attemptId);

	
}
