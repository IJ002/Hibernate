package com.cognizant.model;

import java.time.LocalDate;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Employee {

	
	@Id
	@GeneratedValue
	private Integer emId;
	private String emName;
	private float emSalary;
	private Boolean emPermanent;
	private LocalDate emDateofbirth;
	//private Integer emDpid;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "emDpid")
	private Department department;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "employee_skill",
	joinColumns = @JoinColumn(name = "es_em_id"),
	inverseJoinColumns = @JoinColumn(name = "es_sk_id"))
	private Set<Skill> skillList;
	
	public Set<Skill> getSkillList() {
		return skillList;
	}


	public void setSkillList(Set<Skill> skillList) {
		this.skillList = skillList;
	}
	
	public Integer getEmId() {
		return emId;
	}

	public void setEmId(Integer emId) {
		this.emId = emId;
	}

	public String getEmName() {
		return emName;
	}

	public void setEmName(String emName) {
		this.emName = emName;
	}

	public float getEmSalary() {
		return emSalary;
	}

	public void setEmSalary(float emSalary) {
		this.emSalary = emSalary;
	}

	public Boolean getEmPermanent() {
		return emPermanent;
	}

	public void setEmPermanent(Boolean emPermanent) {
		this.emPermanent = emPermanent;
	}

	public LocalDate getEmDateofbirth() {
		return emDateofbirth;
	}

	public void setEmDateofbirth(LocalDate emDateofbirth) {
		this.emDateofbirth = emDateofbirth;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public Employee(String emName, float emSalary, Boolean emPermanent, LocalDate emDateofbirth,Department department) {
		super();
		this.emName = emName;
		this.emSalary = emSalary;
		this.emPermanent = emPermanent;
		this.emDateofbirth = emDateofbirth;
		this.department = department;
	}

	public Employee() {
		super();
	}

	@Override
	public String toString() {
		return "emId=" + emId + ", emName=" + emName + ", emSalary=" + emSalary + ", emPermanent="
				+ emPermanent + ", emDateofbirth=" + emDateofbirth + ", department=" + department + "\n";
	}
	
	
	
	
	
}
