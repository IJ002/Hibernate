package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.model.Department;
import com.cognizant.repository.DepartmentRepository;

@Service
public class DepartmentService {

	@Autowired
	private DepartmentRepository departmentRepository;
	@Transactional
	public void saveAllDepartment(List<Department> dptlist) {

		departmentRepository.saveAll(dptlist);
	}
	@Transactional
	public Department findDepartment(String string) {

		return departmentRepository.findByName(string);
	}
	@Transactional
	public void addEmployeetoDepartment(Department dep1) {

		departmentRepository.save(dep1);
	}
	@Transactional
	public Department getbyid(int i) {
		return departmentRepository.findById(i).get();
	}
	
}
