package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.model.Employee;
import com.cognizant.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Transactional
	public void saveEmployee(List<Employee> elist) {
		
		employeeRepository.saveAll(elist);
	}
	@Transactional
	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();
	}
	@Transactional
	public Employee getbyid(int i) {
		return employeeRepository.findById(i).get();
	}
	@Transactional
	public void save(Employee emptoUpdate) {

		employeeRepository.save(emptoUpdate);
	}
	public Employee getbyName(String string) {
		return employeeRepository.findByEmName(string);
	}
	public List<Employee> getAllPermanentEmployees() {
		return employeeRepository.getAllPermanentEmployees();
	}


}
