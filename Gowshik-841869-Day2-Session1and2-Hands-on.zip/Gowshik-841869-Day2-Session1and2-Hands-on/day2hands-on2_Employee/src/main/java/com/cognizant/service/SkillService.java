package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.model.Skill;
import com.cognizant.repository.SkillRepository;

@Service
public class SkillService {

	@Autowired
	private SkillRepository skillRepository;

	public void addSkils(List<Skill> slist) {

		skillRepository.saveAll(slist);
	}

	public Skill getbySkillName(String string) {
		return skillRepository.findByName(string);
	}
}
