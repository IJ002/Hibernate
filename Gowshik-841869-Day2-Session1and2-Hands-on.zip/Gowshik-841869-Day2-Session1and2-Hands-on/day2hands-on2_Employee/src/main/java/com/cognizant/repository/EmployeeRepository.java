package com.cognizant.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer>{

	public Employee findByEmName(String string);
	
	@Query(value="SELECT e FROM Employee e left join fetch e.department d left join fetch e.skillList WHERE e.emPermanent = 1")
	List<Employee> getAllPermanentEmployees();

	//@Query(value="SELECT AVG(e.emSalary) FROM Employee e where e.emDpid.id = :id")
	//double getAverageSalary(@Param("id") int id);
	
	@Query(value="SELECT AVG(e.emSalary) FROM Employee e")
	double getAverageSalary();
	
//	@Query(value="SELECT * FROM Employee", nativeQuery = true)
//	public List<Employee> getAllusingNativeQuery();



	
}
