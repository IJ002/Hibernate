package com.cognizant.ormlearn;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.cognizant.model.Department;
import com.cognizant.model.Employee;
import com.cognizant.model.Skill;
import com.cognizant.service.DepartmentService;
import com.cognizant.service.EmployeeService;
import com.cognizant.service.SkillService;


//Gowshik's Day 2 Seesion 1 and some session2 hands-on For Employee database
//make sure localhost changed to 3307 to 3306
//set db as day2handsonemployee
// also do maven install before running to download packages
@SpringBootApplication
@EntityScan(basePackages = {"com"})
@ComponentScan(basePackages = {"com.cognizant.service"})
@EnableJpaRepositories(basePackages = {"com.cognizant.repository"})
public class HandsOnDay2_Employee implements CommandLineRunner{
	
	private static final Logger logger =  LoggerFactory.getLogger(HandsOnDay2_Employee.class);


	
	@Autowired
	private DepartmentService departmentService;
	
	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private SkillService skillService;
	
	public static void main(String[] args) {
		SpringApplication.run(HandsOnDay2_Employee.class, args);
		logger.info("Inside Main");
	}

	// Commandline Runner
	@Override
	public void run(String... args) throws Exception {

			storeDepartments();
			storeEmployee();
			updateEmployee();
			getDepartment();
			storeSkillsTable();
			addSkillstoEmployees();
			fetchEmployeesAlongwithSkills();
			getAllpermanentEmployees();
	}
	
	
	
	private void getAllpermanentEmployees() {

		List<Employee> permanentEmployees = employeeService.getAllPermanentEmployees();
		System.out.println("---------------------List of Permanent employees----------------------------");
		permanentEmployees.forEach(e->System.out.println(e));
	}

	private void fetchEmployeesAlongwithSkills() {

		Employee employee = employeeService.getbyName("Gowshik");
		System.out.println("---------Fetching details of Employee along with skills-----------------");
		System.out.println(employee.getSkillList());
		System.out.println("------------------Fetched----------------------");
	}

	private void storeSkillsTable() {

		Skill sk1 = new Skill("C");
		Skill sk2 = new Skill("MAnagementSkills");
		Skill sk3 = new Skill("JAVA");
		Skill sk4 = new Skill("NEtworks");
		Skill sk5 = new Skill("Angular");
		List<Skill> slist = new ArrayList<Skill>();
		slist.add(sk1);slist.add(sk2);slist.add(sk3);slist.add(sk4);slist.add(sk5);
		skillService.addSkils(slist);
	}

	private void addSkillstoEmployees() {

		Employee employee = employeeService.getbyName("Gowshik");
		Set<Skill> skilllist = new HashSet<Skill>();
		skilllist.add(skillService.getbySkillName("JAVA"));
		skilllist.add(skillService.getbySkillName("Angular"));
		
		employee.setSkillList(skilllist);
		System.out.println("----------------Adding skills to employee-------------------");
		employeeService.save(employee);
		System.out.println("------------------Added Skills to the Employee---------------");
	}

	private void getDepartment() {

		Department department = departmentService.getbyid(1);
		System.out.println("getting Details of the Department employee");  //dept id 1 --> Development
		System.out.println("Department : "+department.getName());
		System.out.println(department.getEmployee());
	}

	private void storeDepartments() {
		Department dept1 = new Department("Development");
		Department dept2 = new Department("Testing");
		Department dept3 = new Department("Support");
		Department dept4 = new Department("Technical Support");
		Department dept5 = new Department("HR MAnager");
		List<Department> dptlist =new ArrayList<Department>();
		dptlist.add(dept1);
		dptlist.add(dept2);
		dptlist.add(dept3);
		dptlist.add(dept4);
		dptlist.add(dept5);
		departmentService.saveAllDepartment(dptlist);   // saving the departments
	}

	private void updateEmployee() {
		
		Employee emptoUpdate = employeeService.getbyid(7);   // id 7 is Jason  -> TEchnical support
 		if(emptoUpdate!=null)
		{
			Department finddept = departmentService.getbyid(5);
			emptoUpdate.setDepartment(finddept);
			employeeService.save(emptoUpdate);
			System.out.println("Department of id 7 changed to :"+ employeeService.getbyid(7).getDepartment().getName());
			System.out.println("------------Updated-------------------");
		}
		
	}

	
	
	private void storeEmployee() {
			
			
			//Adding employees
			Employee e1 = new Employee("Gowshik",45000.50f,true,LocalDate.of(1998, 10, 13),departmentService.findDepartment("Development"));
			Employee e2 = new Employee("JAson",35000.50f,false,LocalDate.of(1998, 12, 1),departmentService.findDepartment("Support"));
			Employee e3 = new Employee("Jaisureya",39000.50f,true,LocalDate.of(1998, 8, 3),departmentService.findDepartment("Technical Support"));
			Employee e4 = new Employee("HAri",25000.50f,false,LocalDate.of(1999, 3, 23),departmentService.findDepartment("Testing"));
			Employee e5 = new Employee("Jagajeet",55000.50f,true,LocalDate.of(1998, 5, 7),departmentService.findDepartment("Development"));
			
			List<Employee> elist = new ArrayList<Employee>();
			elist.add(e1);elist.add(e2);elist.add(e3);elist.add(e4);elist.add(e5);
			employeeService.saveEmployee(elist);
			
			System.out.println("Getting all employees and thweir department");
			List<Employee> list = employeeService.getAllEmployees();
			list.forEach(e->System.out.println(e));
//			Set<Employee> setOfEmployees = getEmployees();
//			Department dep1 = new Department("Development",setOfEmployees);
//			departmentService.addEmployeetoDepartment(dep1);
			
			System.out.println("----------------Added--------------------------");
		
	}

//	private Set<Employee> getEmployees() {
//
//		Employee e1 = new Employee("Gowshik",45000.50f,true,LocalDate.of(1998, 10, 13));
//		Set<Employee> set = new HashSet<Employee>();
//		set.add(e1);
//		return set;
//	}

	


}
