package com.example.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.Country;

public interface Day1Repo extends JpaRepository<Country, String> {

	public List<Country> findAll();

	public Country findByCode(String id);

	public Country save(Country country);

	public void deleteById(String id);

}
