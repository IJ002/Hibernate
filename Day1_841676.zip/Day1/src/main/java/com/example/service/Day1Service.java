package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.Country;
import com.example.repo.Day1Repo;

@Service
public class Day1Service {

	@Autowired
	Day1Repo countryRepository;

	public List<Country> findAll() {
		return countryRepository.findAll();
	}

	public Country findById(String id) {

		return countryRepository.findByCode(id);

	}

	public void save(Country country) {

		countryRepository.save(country);
	}

	public void deleteByCode(String id) {
		countryRepository.deleteById(id);
	}
	
}
