package com.example.demo;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.example.model.Country;
import com.example.service.Day1Service;

@SpringBootApplication
@EntityScan(basePackages = "com.example.model")
@ComponentScan(basePackages = "com.example.service")
@EnableJpaRepositories(basePackages = "com.example.repo")
public class Day1Application implements CommandLineRunner {

	@Autowired
	Day1Service day1;
	
	public static void main(String[] args) {
		SpringApplication.run(Day1Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);
		String id;
		System.out.println("Enter the country code: ");
		id = sc.next();

		Country countryByCode = day1.findById(id);

		if (countryByCode == null) {
			System.out.println("The code " + id + " does not match any country code in the database");
		} else {
			System.out.println("The country code: " + countryByCode.getCode());
			System.out.println("The country name: " + countryByCode.getName());
		}
		Country country = new Country();
		try {
			System.out.println("Enter the country code: ");
			country.setCode(sc.next());
			System.out.println("Enter the country name: ");
			country.setName(sc.next());
		} catch (Exception e) {
			System.out.println("ID Already Exists");
			return;
		}
		day1.save(country);
		System.out.println("Day1Service saved");

		System.out.println("Enter the country code whose value is to be updated: ");
		id = sc.next();

		if (day1.findById(id) != null) {
			System.out.println("Enter the country's new name: ");
			String countryName = sc.next();

			Country updateCountry = new Country();
			updateCountry.setCode(id);
			updateCountry.setName(countryName);

			day1.save(updateCountry);
			System.out.println("Day1Service name updated!");

		}
		
		System.out.println("Enter the code of the country which is to be deleted");
		id = sc.next();
		
		day1.deleteByCode(id);
		
		
	}

}
